import random
import sys
import json


def simular_taller(ordenes):

    resultados = []

    for orden in ordenes:

        servicio = orden["servicio"]

        # Tiempo de servicio según el tipo de trabajo
        if servicio == "Cambio de aceite":
            tiempo_servicio = random.randint(15, 30)

        elif servicio == "Frenos":
            tiempo_servicio = random.randint(30, 60)

        else:
            tiempo_servicio = random.randint(60, 180)

        # Tiempo que espera el vehículo antes de ser atendido
        tiempo_espera = random.randint(5, 25)

        tiempo_total = (
            tiempo_servicio +
            tiempo_espera
        )

        resultados.append({

            "orden": orden["orden"],

            "vehiculo": orden["vehiculo"],

            "placas": orden["placas"],

            "servicio": servicio,

            "mecanico": orden["mecanico"],

            "tiempo_espera": tiempo_espera,

            "tiempo_servicio": tiempo_servicio,

            "tiempo_total": tiempo_total
        })

    return resultados


if __name__ == "__main__":

    try:

        # Java enviará los datos mediante JSON
        datos = sys.stdin.read()

        ordenes = json.loads(datos)

        resultados = simular_taller(ordenes)

        print(
            json.dumps(
                resultados,
                ensure_ascii=False
            )
        )

    except Exception as e:

        print(
            json.dumps(
                {
                    "error": str(e)
                },
                ensure_ascii=False
            )
        )
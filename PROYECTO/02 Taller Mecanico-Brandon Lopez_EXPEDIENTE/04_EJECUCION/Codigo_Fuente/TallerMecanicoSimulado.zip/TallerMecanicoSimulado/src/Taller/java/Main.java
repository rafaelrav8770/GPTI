package taller;

public class Main {

    public static void main(String[] args) {

        TallerGUI.main(args);

    }
}

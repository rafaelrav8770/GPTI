package com.nietosystems.aguacero.simulacion;

public enum EstadoGarrafon {

    RECEPCION,

    CLASIFICACION,

    COLA_LAVADO_SIMPLE,
    LAVADO_SIMPLE,

    COLA_LAVADO_PROFUNDO,
    LAVADO_PROFUNDO,

    COLA_LLENADO,
    CARGA_LLENADORA,
    LLENADO,
    DESCARGA_LLENADORA,

    COLA_TAPADO_SELLADO,
    TAPADO_SELLADO,

    // Garrafón sellado esperando que E4 forme un grupo de 4
    COLA_TRASLADO,

    // Grupo de 4 siendo llevado al área de producto terminado
    TRASLADO_PRODUCTO_TERMINADO,

    TERMINADO
}
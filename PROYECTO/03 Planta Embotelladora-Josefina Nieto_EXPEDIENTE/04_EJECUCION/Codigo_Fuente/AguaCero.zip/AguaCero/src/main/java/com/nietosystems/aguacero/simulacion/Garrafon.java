package com.nietosystems.aguacero.simulacion;

/**
 * Representa un garrafón individual dentro
 * de la simulación de la planta Agua Cero.
 */
public class Garrafon {

    // =========================================================
    // DATOS GENERALES
    // =========================================================

    /**
     * Identificador único del garrafón.
     * Ejemplo: 1, 2, 3, 4...
     */
    private final int id;


    /**
     * Tipo de lavado asignado al garrafón.
     */
    private TipoLavado tipoLavado;


    /**
     * Estado actual del garrafón dentro de la planta.
     */
    private EstadoGarrafon estado;


    // =========================================================
    // TIEMPOS DE LA SIMULACIÓN
    // =========================================================

    /**
     * Segundo simulado en el que llegó a la planta.
     */
    private double tiempoLlegada;


    /**
     * Segundo simulado en el que comenzó
     * su proceso de lavado.
     */
    private double tiempoInicioLavado;


    /**
     * Segundo simulado en el que terminó
     * su proceso de lavado.
     */
    private double tiempoFinLavado;


    /**
     * Segundo simulado en el que entró
     * a la cola de llenado.
     */
    private double tiempoEntradaColaLlenado;


    /**
     * Segundo simulado en el que comenzó
     * el proceso de llenado.
     */
    private double tiempoInicioLlenado;


    /**
     * Segundo simulado en el que terminó
     * el proceso de llenado.
     */
    private double tiempoFinLlenado;


    /**
     * Segundo simulado en el que el garrafón
     * terminó completamente su proceso.
     */
    private double tiempoTerminado;


    // =========================================================
    // TIEMPOS ACUMULADOS
    // =========================================================

    /**
     * Tiempo total que el garrafón permaneció
     * esperando en diferentes colas.
     */
    private double tiempoTotalEspera;


    // =========================================================
    // CONSTRUCTOR
    // =========================================================

    public Garrafon(
            int id,
            TipoLavado tipoLavado,
            double tiempoLlegada) {

        this.id = id;
        this.tipoLavado = tipoLavado;
        this.tiempoLlegada = tiempoLlegada;

        // Todo garrafón comienza en recepción.
        this.estado = EstadoGarrafon.RECEPCION;

        this.tiempoInicioLavado = 0;
        this.tiempoFinLavado = 0;
        this.tiempoEntradaColaLlenado = 0;
        this.tiempoInicioLlenado = 0;
        this.tiempoFinLlenado = 0;
        this.tiempoTerminado = 0;
        this.tiempoTotalEspera = 0;
    }


    // =========================================================
    // GETTERS
    // =========================================================

    public int getId() {
        return id;
    }


    public TipoLavado getTipoLavado() {
        return tipoLavado;
    }


    public EstadoGarrafon getEstado() {
        return estado;
    }


    public double getTiempoLlegada() {
        return tiempoLlegada;
    }


    public double getTiempoInicioLavado() {
        return tiempoInicioLavado;
    }


    public double getTiempoFinLavado() {
        return tiempoFinLavado;
    }


    public double getTiempoEntradaColaLlenado() {
        return tiempoEntradaColaLlenado;
    }


    public double getTiempoInicioLlenado() {
        return tiempoInicioLlenado;
    }


    public double getTiempoFinLlenado() {
        return tiempoFinLlenado;
    }


    public double getTiempoTerminado() {
        return tiempoTerminado;
    }


    public double getTiempoTotalEspera() {
        return tiempoTotalEspera;
    }


    // =========================================================
    // SETTERS
    // =========================================================

    public void setTipoLavado(TipoLavado tipoLavado) {
        this.tipoLavado = tipoLavado;
    }


    public void setEstado(EstadoGarrafon estado) {
        this.estado = estado;
    }


    public void setTiempoLlegada(double tiempoLlegada) {
        this.tiempoLlegada = tiempoLlegada;
    }


    public void setTiempoInicioLavado(double tiempoInicioLavado) {
        this.tiempoInicioLavado = tiempoInicioLavado;
    }


    public void setTiempoFinLavado(double tiempoFinLavado) {
        this.tiempoFinLavado = tiempoFinLavado;
    }


    public void setTiempoEntradaColaLlenado(double tiempoEntradaColaLlenado) {
        this.tiempoEntradaColaLlenado = tiempoEntradaColaLlenado;
    }


    public void setTiempoInicioLlenado(double tiempoInicioLlenado) {
        this.tiempoInicioLlenado = tiempoInicioLlenado;
    }


    public void setTiempoFinLlenado(double tiempoFinLlenado) {
        this.tiempoFinLlenado = tiempoFinLlenado;
    }


    public void setTiempoTerminado(double tiempoTerminado) {
        this.tiempoTerminado = tiempoTerminado;
    }


    public void setTiempoTotalEspera(double tiempoTotalEspera) {
        this.tiempoTotalEspera = tiempoTotalEspera;
    }


    // =========================================================
    // MÉTODOS AUXILIARES
    // =========================================================

    /**
     * Agrega tiempo de espera al acumulado
     * del garrafón.
     */
    public void agregarTiempoEspera(double segundos) {

        if (segundos > 0) {
            tiempoTotalEspera += segundos;
        }
    }


    /**
     * Calcula cuánto tiempo permaneció el garrafón
     * dentro del sistema completo.
     */
    public double calcularTiempoTotalSistema() {

        if (tiempoTerminado <= 0) {
            return 0;
        }

        return tiempoTerminado - tiempoLlegada;
    }


    /**
     * Indica si el garrafón ya terminó
     * todo su proceso.
     */
    public boolean estaTerminado() {
        return estado == EstadoGarrafon.TERMINADO;
    }


    @Override
    public String toString() {

        return "Garrafon{" +
                "id=" + id +
                ", tipoLavado=" + tipoLavado +
                ", estado=" + estado +
                '}';
    }
}
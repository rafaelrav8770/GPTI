package com.nietosystems.aguacero;

import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.stage.Screen;
import javafx.stage.Stage;

import java.io.IOException;


/**
 * Ventana "Acerca del proyecto" de Agua Cero.
 *
 * Utiliza el mismo Stage principal de la aplicación
 * para mantener una navegación uniforme entre módulos.
 */
public class AcercaApplication {


    // =========================================================
    // MOSTRAR ACERCA DEL PROYECTO
    // =========================================================

    public static void mostrar() {

        try {

            // =================================================
            // CARGAR FXML
            // =================================================

            FXMLLoader loader =
                    new FXMLLoader(
                            AcercaApplication.class.getResource(
                                    "acerca-view.fxml"
                            )
                    );


            // =================================================
            // OBTENER ÁREA DISPONIBLE DE LA PANTALLA
            // =================================================

            Rectangle2D pantallaDisponible =
                    Screen.getPrimary().getVisualBounds();


            // =================================================
            // CREAR ESCENA
            // =================================================

            Scene scene =
                    new Scene(
                            loader.load(),
                            pantallaDisponible.getWidth(),
                            pantallaDisponible.getHeight()
                    );


            // =================================================
            // UTILIZAR LA MISMA VENTANA PRINCIPAL
            // =================================================

            /*
             * No se crea un nuevo Stage.
             *
             * Se utiliza la misma ventana principal de Agua Cero,
             * igual que en Configuración y los demás módulos.
             */

            Stage stage =
                    MainApplication.getStagePrincipal();


            // =================================================
            // CONFIGURAR VENTANA
            // =================================================

            stage.setTitle(
                    "Agua Cero | Acerca del proyecto"
            );

            stage.setScene(scene);

            stage.setMinWidth(850);
            stage.setMinHeight(600);


            // =================================================
            // AJUSTAR A LA PANTALLA
            // =================================================

            stage.setX(
                    pantallaDisponible.getMinX()
            );

            stage.setY(
                    pantallaDisponible.getMinY()
            );

            stage.setWidth(
                    pantallaDisponible.getWidth()
            );

            stage.setHeight(
                    pantallaDisponible.getHeight()
            );


            // =================================================
            // BOTÓN X DE WINDOWS
            // =================================================

            /*
             * Si el usuario presiona X desde esta pantalla,
             * regresamos al menú principal en lugar de cerrar
             * completamente Agua Cero.
             */

            stage.setOnCloseRequest(event -> {

                event.consume();

                MainApplication.mostrarPrincipal();
            });


        } catch (IOException e) {

            System.err.println(
                    "Error al abrir la ventana Acerca del proyecto."
            );

            e.printStackTrace();
        }
    }
}
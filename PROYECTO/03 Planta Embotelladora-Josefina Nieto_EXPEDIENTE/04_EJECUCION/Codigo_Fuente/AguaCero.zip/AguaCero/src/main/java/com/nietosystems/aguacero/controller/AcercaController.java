package com.nietosystems.aguacero.controller;

import com.nietosystems.aguacero.MainApplication;

import javafx.fxml.FXML;


/**
 * Controlador de la ventana Acerca del proyecto.
 */
public class AcercaController {


    // =========================================================
    // REGRESAR
    // =========================================================

    @FXML
    protected void onRegresarClick() {

        MainApplication.mostrarPrincipal();
    }
}
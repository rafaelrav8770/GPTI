package com.nietosystems.aguacero.simulacion;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Random;

public class MotorSimulacion {

    // =========================================================
    // PARÁMETROS Y RELOJ
    // =========================================================

    private final ParametrosSimulacion parametros;
    private final Random random;

    private double tiempoActual;
    private boolean ejecutando;
    private boolean pausada;


    // =========================================================
    // GARRAFONES Y EMPLEADOS
    // =========================================================

    private final List<Garrafon> garrafones;
    private final List<Garrafon> garrafonesTerminados;
    private final List<Empleado> empleados;


    // =========================================================
    // DESCARGA INICIAL
    // =========================================================

    private static final int CANTIDAD_GRUPO_DESCARGA = 4;
    private static final double TIEMPO_GRUPO_DESCARGA = 45.0;

    private boolean descargaInicialActiva;
    private int garrafonesDescargados;
    private double proximoGrupoDescarga;
    private boolean clasificacionRealizada;


    // =========================================================
    // COLAS
    // =========================================================

    private final Queue<Garrafon> colaRecepcion;
    private final Queue<Garrafon> colaLavadoSimple;
    private final Queue<Garrafon> colaLavadoProfundo;
    private final Queue<Garrafon> colaLlenado;
    private final Queue<Garrafon> colaTapadoSellado;

    // Nueva cola: garrafones sellados esperando traslado
    private final Queue<Garrafon> colaTraslado;


    // =========================================================
    // LAVADO SIMPLE
    // =========================================================

    private Garrafon garrafonLavadoSimple;
    private double finLavadoSimple;


    // =========================================================
    // LAVADO PROFUNDO
    // =========================================================

    private Garrafon garrafonLavadoProfundo;
    private double finLavadoProfundo;


    // =========================================================
    // LLENADORA
    // =========================================================

    private final List<Garrafon> grupoLlenadora;

    /*
     * Estados:
     *
     * LIBRE
     * CARGANDO
     * LLENANDO
     * ESPERANDO_DESCARGA
     * DESCARGANDO
     */
    private String estadoLlenadora;

    private double finEtapaLlenadora;


    // =========================================================
    // TAPADO Y SELLADO
    // EMPLEADO 3 + APOYO OPCIONAL EMPLEADO 5
    // =========================================================

    // Puesto principal - Empleado 3
    private Garrafon garrafonTapadoSellado;
    private double finTapadoSellado;

    // Puesto de apoyo - Empleado 5
    private Garrafon garrafonTapadoSelladoE5;
    private double finTapadoSelladoE5;


    // =========================================================
    // TRASLADO A PRODUCTO TERMINADO - EMPLEADO 4
    // =========================================================

    private static final int CAPACIDAD_TRASLADO = 4;
    private static final double TIEMPO_TRASLADO = 30.0;

    private final List<Garrafon> grupoTraslado;

    private boolean trasladoActivo;
    private double finTraslado;


    // =========================================================
    // CONTADORES
    // =========================================================

    private int totalProcesados;


    // =========================================================
    // CONSTRUCTORES
    // =========================================================

    /**
     * Constructor predeterminado.
     *
     * Se conserva para que el motor pueda seguir funcionando
     * con los parámetros iniciales de Agua Cero cuando no se
     * haya proporcionado una configuración personalizada.
     */
    public MotorSimulacion() {

        this(new ParametrosSimulacion());
    }


    /**
     * Constructor que recibe la configuración seleccionada
     * por el usuario en el módulo de Configuración.
     *
     * @param parametros configuración que utilizará la simulación.
     */
    public MotorSimulacion(ParametrosSimulacion parametros) {

        // Si por alguna razón no recibimos parámetros,
        // utilizamos los valores predeterminados.
        if (parametros != null) {
            this.parametros = parametros;
        } else {
            this.parametros = new ParametrosSimulacion();
        }

        random = new Random();

        garrafones = new ArrayList<>();
        garrafonesTerminados = new ArrayList<>();
        empleados = new ArrayList<>();

        colaRecepcion = new LinkedList<>();
        colaLavadoSimple = new LinkedList<>();
        colaLavadoProfundo = new LinkedList<>();
        colaLlenado = new LinkedList<>();
        colaTapadoSellado = new LinkedList<>();
        colaTraslado = new LinkedList<>();

        grupoLlenadora = new ArrayList<>();
        grupoTraslado = new ArrayList<>();

        tiempoActual = 0;

        ejecutando = false;
        pausada = false;

        descargaInicialActiva = false;
        garrafonesDescargados = 0;
        proximoGrupoDescarga = 0;
        clasificacionRealizada = false;

        garrafonLavadoSimple = null;
        finLavadoSimple = 0;

        garrafonLavadoProfundo = null;
        finLavadoProfundo = 0;

        estadoLlenadora = "LIBRE";
        finEtapaLlenadora = 0;

        garrafonTapadoSellado = null;
        finTapadoSellado = 0;

        garrafonTapadoSelladoE5 = null;
        finTapadoSelladoE5 = 0;

        trasladoActivo = false;
        finTraslado = 0;

        totalProcesados = 0;

        crearEmpleados();
    }


    // =========================================================
    // CREAR EMPLEADOS
    // =========================================================

    private void crearEmpleados() {

        empleados.clear();

        /*
         * Se crean únicamente los empleados que están
         * ACTIVOS en la configuración del escenario.
         */
        for (EmpleadoConfiguracion empleadoConfigurado
                : parametros.getEmpleados()) {

            if (empleadoConfigurado.isActivo()) {

                empleados.add(
                        new Empleado(
                                empleadoConfigurado.getId(),
                                "Empleado " + empleadoConfigurado.getId()
                        )
                );
            }
        }

        /*
         * Protección:
         * Si por alguna razón no existe todavía una lista
         * de empleados configurados, se conserva el
         * comportamiento original del simulador.
         */
        if (empleados.isEmpty()) {

            for (int i = 1;
                 i <= parametros.getNumeroEmpleados();
                 i++) {

                empleados.add(
                        new Empleado(
                                i,
                                "Empleado " + i
                        )
                );
            }
        }
    }


    // =========================================================
    // OBTENER EMPLEADO
    // =========================================================

    private Empleado obtenerEmpleadoPorId(int id) {

        for (Empleado empleado : empleados) {

            if (empleado.getId() == id) {
                return empleado;
            }
        }

        return null;
    }

    private Empleado obtenerEmpleadoDisponibleParaActividad(String actividad) {

        for (EmpleadoConfiguracion configuracion
                : parametros.getEmpleados()) {

            if (!configuracion.isActivo()) {
                continue;
            }

            if (!configuracion
                    .getActividadesPermitidas()
                    .contains(actividad)) {

                continue;
            }

            Empleado empleado =
                    obtenerEmpleadoPorId(
                            configuracion.getId()
                    );

            if (empleado != null
                    && empleado.estaDisponible()) {

                return empleado;
            }
        }

        return null;
    }


    // =========================================================
    // INICIAR SIMULACIÓN
    // =========================================================

    public void iniciar() {

        reiniciarDatos();

        crearGarrafones();

        ejecutando = true;
        pausada = false;

        iniciarDescargaInicial();

        System.out.println(
                "======================================"
        );

        System.out.println(
                "SIMULACIÓN AGUA CERO INICIADA"
        );

        System.out.println(
                "======================================"
        );

        System.out.println(
                "Garrafones: "
                        + parametros.getGarrafonesPorCamion()
        );

        System.out.println(
                "Descarga: 4 garrafones cada 45 segundos"
        );

        System.out.println(
                "Traslado final: 4 garrafones cada 30 segundos"
        );

        System.out.println(
                "======================================"
        );
    }


    // =========================================================
    // CREAR GARRAFONES
    // =========================================================

    private void crearGarrafones() {

        int total =
                parametros.getGarrafonesPorCamion();

        for (int i = 1; i <= total; i++) {

            TipoLavado tipo =
                    generarTipoLavado();

            Garrafon garrafon =
                    new Garrafon(
                            i,
                            tipo,
                            tiempoActual
                    );

            garrafon.setEstado(
                    EstadoGarrafon.RECEPCION
            );

            garrafones.add(garrafon);
            colaRecepcion.offer(garrafon);
        }
    }


    // =========================================================
    // GENERAR TIPO DE LAVADO
    // =========================================================

    private TipoLavado generarTipoLavado() {

        double valor =
                random.nextDouble() * 100.0;

        if (valor
                < parametros.getPorcentajeMuySucio()) {

            return TipoLavado.PROFUNDO;
        }

        return TipoLavado.SIMPLE;
    }


    // =========================================================
    // DESCARGA INICIAL
    // =========================================================

    private void iniciarDescargaInicial() {

        descargaInicialActiva = true;

        garrafonesDescargados = 0;

        proximoGrupoDescarga =
                tiempoActual
                        + TIEMPO_GRUPO_DESCARGA;

        Empleado empleado1 =
                obtenerEmpleadoPorId(1);

        Empleado empleado2 =
                obtenerEmpleadoPorId(2);

        if (empleado1 != null
                && empleado1.estaDisponible()) {

            empleado1.iniciarActividad(
                    "Descarga inicial del camión",
                    tiempoActual
            );
        }

        if (empleado2 != null
                && empleado2.estaDisponible()) {

            empleado2.iniciarActividad(
                    "Descarga inicial del camión",
                    tiempoActual
            );
        }
    }


    private void procesarDescargaInicial() {

        if (!descargaInicialActiva) {
            return;
        }

        if (tiempoActual
                < proximoGrupoDescarga) {

            return;
        }

        garrafonesDescargados +=
                CANTIDAD_GRUPO_DESCARGA;

        if (garrafonesDescargados
                > parametros.getGarrafonesPorCamion()) {

            garrafonesDescargados =
                    parametros.getGarrafonesPorCamion();
        }

        System.out.println(
                "Tiempo "
                        + (int) tiempoActual
                        + " s -> Descarga: "
                        + garrafonesDescargados
                        + " / "
                        + parametros.getGarrafonesPorCamion()
        );

        if (garrafonesDescargados
                >= parametros.getGarrafonesPorCamion()) {

            finalizarDescargaInicial();

        } else {

            proximoGrupoDescarga =
                    tiempoActual
                            + TIEMPO_GRUPO_DESCARGA;
        }
    }


    private void finalizarDescargaInicial() {

        descargaInicialActiva = false;

        proximoGrupoDescarga = 0;

        Empleado empleado1 =
                obtenerEmpleadoPorId(1);

        Empleado empleado2 =
                obtenerEmpleadoPorId(2);

        if (empleado1 != null
                && empleado1.isOcupado()) {

            empleado1.finalizarActividad(
                    tiempoActual
            );
        }

        if (empleado2 != null
                && empleado2.isOcupado()) {

            empleado2.finalizarActividad(
                    tiempoActual
            );
        }

        System.out.println(
                "Descarga inicial completada en "
                        + tiempoActual
                        + " segundos."
        );
    }


    // =========================================================
    // CLASIFICACIÓN
    // =========================================================

    private void clasificarTodosLosGarrafones() {

        if (clasificacionRealizada) {
            return;
        }

        if (descargaInicialActiva) {
            return;
        }

        while (!colaRecepcion.isEmpty()) {

            clasificarSiguienteGarrafon();
        }

        clasificacionRealizada = true;

        System.out.println(
                "Clasificación completada."
        );

        System.out.println(
                "Lavado simple: "
                        + colaLavadoSimple.size()
        );

        System.out.println(
                "Lavado profundo: "
                        + colaLavadoProfundo.size()
        );
    }


    public void clasificarSiguienteGarrafon() {

        if (colaRecepcion.isEmpty()) {
            return;
        }

        Garrafon garrafon =
                colaRecepcion.poll();

        garrafon.setEstado(
                EstadoGarrafon.CLASIFICACION
        );

        if (garrafon.getTipoLavado()
                == TipoLavado.SIMPLE) {

            garrafon.setEstado(
                    EstadoGarrafon.COLA_LAVADO_SIMPLE
            );

            colaLavadoSimple.offer(
                    garrafon
            );

        } else {

            garrafon.setEstado(
                    EstadoGarrafon.COLA_LAVADO_PROFUNDO
            );

            colaLavadoProfundo.offer(
                    garrafon
            );
        }
    }


    // =========================================================
    // LAVADO SIMPLE - EMPLEADO 1
    // =========================================================

    private void procesarLavadoSimple() {

        Empleado empleado1 =
                obtenerEmpleadoPorId(1);

        if (empleado1 == null) {
            return;
        }

        /*
         * Primero comprobamos si terminó
         * el lavado actual.
         */
        if (garrafonLavadoSimple != null) {

            if (tiempoActual
                    >= finLavadoSimple) {

                garrafonLavadoSimple
                        .setTiempoFinLavado(
                                tiempoActual
                        );

                enviarAColaLlenado(
                        garrafonLavadoSimple
                );

                garrafonLavadoSimple = null;

                finLavadoSimple = 0;

                empleado1.finalizarActividad(
                        tiempoActual
                );
            }

            return;
        }

        /*
         * Si E1 está ocupado en otra tarea,
         * no puede iniciar lavado.
         */
        if (!empleado1.estaDisponible()) {
            return;
        }

        if (colaLavadoSimple.isEmpty()) {
            return;
        }

        garrafonLavadoSimple =
                colaLavadoSimple.poll();

        garrafonLavadoSimple.setEstado(
                EstadoGarrafon.LAVADO_SIMPLE
        );

        garrafonLavadoSimple
                .setTiempoInicioLavado(
                        tiempoActual
                );

        empleado1.iniciarActividad(
                "Lavado simple",
                tiempoActual
        );

        finLavadoSimple =
                tiempoActual
                        + parametros
                        .getTiempoLavadoSimple();
    }


    // =========================================================
    // LAVADO PROFUNDO - EMPLEADO 2
    // =========================================================

    private void procesarLavadoProfundo() {

        Empleado empleado2 =
                obtenerEmpleadoPorId(2);

        if (empleado2 == null) {
            return;
        }

        if (garrafonLavadoProfundo != null) {

            if (tiempoActual
                    >= finLavadoProfundo) {

                garrafonLavadoProfundo
                        .setTiempoFinLavado(
                                tiempoActual
                        );

                enviarAColaLlenado(
                        garrafonLavadoProfundo
                );

                garrafonLavadoProfundo = null;

                finLavadoProfundo = 0;

                empleado2.finalizarActividad(
                        tiempoActual
                );
            }

            return;
        }

        if (!empleado2.estaDisponible()) {
            return;
        }

        if (colaLavadoProfundo.isEmpty()) {
            return;
        }

        garrafonLavadoProfundo =
                colaLavadoProfundo.poll();

        garrafonLavadoProfundo.setEstado(
                EstadoGarrafon.LAVADO_PROFUNDO
        );

        garrafonLavadoProfundo
                .setTiempoInicioLavado(
                        tiempoActual
                );

        empleado2.iniciarActividad(
                "Lavado profundo",
                tiempoActual
        );

        finLavadoProfundo =
                tiempoActual
                        + parametros
                        .getTiempoLavadoProfundo();
    }


    // =========================================================
    // COLA DE LLENADO
    // =========================================================

    public void enviarAColaLlenado(
            Garrafon garrafon) {

        if (garrafon == null) {
            return;
        }

        garrafon.setEstado(
                EstadoGarrafon.COLA_LLENADO
        );

        garrafon.setTiempoEntradaColaLlenado(
                tiempoActual
        );

        colaLlenado.offer(
                garrafon
        );
    }


    public boolean hayGrupoParaLlenado() {

        return colaLlenado.size()
                >= parametros
                .getCapacidadLlenadora();
    }


    public List<Garrafon> obtenerGrupoParaLlenado() {

        List<Garrafon> grupo =
                new ArrayList<>();

        if (!hayGrupoParaLlenado()) {
            return grupo;
        }

        int capacidad =
                parametros
                        .getCapacidadLlenadora();

        for (int i = 0;
             i < capacidad;
             i++) {

            Garrafon garrafon =
                    colaLlenado.poll();

            if (garrafon != null) {

                garrafon.setEstado(
                        EstadoGarrafon
                                .CARGA_LLENADORA
                );

                grupo.add(
                        garrafon
                );
            }
        }

        return grupo;
    }


    // =========================================================
    // LLENADORA
    // =========================================================

    private void procesarLlenadora() {

        Empleado empleado1 =
                obtenerEmpleadoPorId(1);

        Empleado empleado3 =
                obtenerEmpleadoPorId(3);

        if (empleado1 == null
                || empleado3 == null) {

            return;
        }


        // -----------------------------------------------------
        // LIBRE
        // -----------------------------------------------------

        if (estadoLlenadora.equals("LIBRE")) {

            if (!hayGrupoParaLlenado()) {
                return;
            }

            /*
             * E1 debe estar disponible
             * para cargar la máquina.
             */
            if (!empleado1.estaDisponible()) {
                return;
            }

            grupoLlenadora.clear();

            grupoLlenadora.addAll(
                    obtenerGrupoParaLlenado()
            );

            empleado1.iniciarActividad(
                    "Carga de máquina llenadora",
                    tiempoActual
            );

            estadoLlenadora =
                    "CARGANDO";

            finEtapaLlenadora =
                    tiempoActual
                            + parametros
                            .getTiempoCargaLlenadora();

            return;
        }


        // -----------------------------------------------------
        // CARGANDO
        // -----------------------------------------------------

        if (estadoLlenadora.equals("CARGANDO")
                && tiempoActual
                >= finEtapaLlenadora) {

            empleado1.finalizarActividad(
                    tiempoActual
            );

            for (Garrafon garrafon :
                    grupoLlenadora) {

                garrafon.setEstado(
                        EstadoGarrafon.LLENADO
                );

                garrafon.setTiempoInicioLlenado(
                        tiempoActual
                );
            }

            estadoLlenadora =
                    "LLENANDO";

            finEtapaLlenadora =
                    tiempoActual
                            + parametros
                            .getTiempoProcesoLlenado();

            return;
        }


        // -----------------------------------------------------
        // LLENANDO
        // -----------------------------------------------------

        if (estadoLlenadora.equals("LLENANDO")
                && tiempoActual
                >= finEtapaLlenadora) {

            for (Garrafon garrafon :
                    grupoLlenadora) {

                garrafon.setTiempoFinLlenado(
                        tiempoActual
                );
            }

            /*
             * El llenado terminó, pero E3
             * puede estar sellando otro garrafón.
             *
             * Por eso la máquina queda esperando.
             */
            estadoLlenadora =
                    "ESPERANDO_DESCARGA";

            finEtapaLlenadora = 0;

            return;
        }


        // -----------------------------------------------------
        // ESPERANDO A EMPLEADO 3
        // -----------------------------------------------------

        if (estadoLlenadora
                .equals("ESPERANDO_DESCARGA")) {

            if (!empleado3.estaDisponible()) {
                return;
            }

            for (Garrafon garrafon :
                    grupoLlenadora) {

                garrafon.setEstado(
                        EstadoGarrafon
                                .DESCARGA_LLENADORA
                );
            }

            empleado3.iniciarActividad(
                    "Descarga de máquina llenadora",
                    tiempoActual
            );

            estadoLlenadora =
                    "DESCARGANDO";

            finEtapaLlenadora =
                    tiempoActual
                            + parametros
                            .getTiempoDescargaLlenadora();

            return;
        }


        // -----------------------------------------------------
        // DESCARGANDO
        // -----------------------------------------------------

        if (estadoLlenadora.equals("DESCARGANDO")
                && tiempoActual
                >= finEtapaLlenadora) {

            empleado3.finalizarActividad(
                    tiempoActual
            );

            for (Garrafon garrafon :
                    grupoLlenadora) {

                garrafon.setEstado(
                        EstadoGarrafon
                                .COLA_TAPADO_SELLADO
                );

                colaTapadoSellado.offer(
                        garrafon
                );
            }

            grupoLlenadora.clear();

            estadoLlenadora =
                    "LIBRE";

            finEtapaLlenadora = 0;
        }
    }


    // =========================================================
    // TAPADO Y SELLADO - EMPLEADO 3
    // =========================================================

    private void procesarTapadoSellado() {

        Empleado empleado3 =
                obtenerEmpleadoPorId(3);

        Empleado empleado5 =
                obtenerEmpleadoPorId(5);


        // =====================================================
        // 1. TERMINAR TRABAJO DEL EMPLEADO 3
        // =====================================================

        if (garrafonTapadoSellado != null
                && tiempoActual >= finTapadoSellado) {

            enviarAColaTraslado(
                    garrafonTapadoSellado
            );

            garrafonTapadoSellado = null;

            finTapadoSellado = 0;

            if (empleado3 != null
                    && empleado3.isOcupado()) {

                empleado3.finalizarActividad(
                        tiempoActual
                );
            }
        }


        // =====================================================
        // 2. TERMINAR TRABAJO DEL EMPLEADO 5
        // =====================================================

        if (garrafonTapadoSelladoE5 != null
                && tiempoActual >= finTapadoSelladoE5) {

            enviarAColaTraslado(
                    garrafonTapadoSelladoE5
            );

            garrafonTapadoSelladoE5 = null;

            finTapadoSelladoE5 = 0;

            if (empleado5 != null
                    && empleado5.isOcupado()) {

                empleado5.finalizarActividad(
                        tiempoActual
                );
            }
        }


        // =====================================================
        // 3. EMPLEADO 3 TOMA EL SIGUIENTE GARRAFÓN
        // =====================================================

        if (empleado3 != null
                && empleado3.estaDisponible()
                && garrafonTapadoSellado == null
                && !colaTapadoSellado.isEmpty()) {

            garrafonTapadoSellado =
                    colaTapadoSellado.poll();

            garrafonTapadoSellado.setEstado(
                    EstadoGarrafon.TAPADO_SELLADO
            );

            empleado3.iniciarActividad(
                    "Tapado y sellado",
                    tiempoActual
            );

            finTapadoSellado =
                    tiempoActual
                            + parametros
                            .getTiempoTapadoSellado();
        }


        // =====================================================
        // 4. EMPLEADO 5 APOYA SI ESTÁ ACTIVO
        // =====================================================

        /*
         * Si E5 no fue activado en Configuración,
         * obtenerEmpleadoPorId(5) devuelve null
         * y este bloque simplemente no se ejecuta.
         *
         * Si está activo, toma un segundo garrafón
         * cuando existe trabajo esperando.
         */
        if (empleado5 != null
                && empleado5.estaDisponible()
                && garrafonTapadoSelladoE5 == null
                && !colaTapadoSellado.isEmpty()) {

            garrafonTapadoSelladoE5 =
                    colaTapadoSellado.poll();

            garrafonTapadoSelladoE5.setEstado(
                    EstadoGarrafon.TAPADO_SELLADO
            );

            empleado5.iniciarActividad(
                    "Apoyo en tapado y sellado",
                    tiempoActual
            );

            finTapadoSelladoE5 =
                    tiempoActual
                            + parametros
                            .getTiempoTapadoSellado();
        }
    }


    // =========================================================
    // ENVIAR A COLA DE TRASLADO
    // =========================================================

    private void enviarAColaTraslado(
            Garrafon garrafon) {

        if (garrafon == null) {
            return;
        }

        garrafon.setEstado(
                EstadoGarrafon.COLA_TRASLADO
        );

        colaTraslado.offer(
                garrafon
        );
    }


    // =========================================================
    // TRASLADO FINAL - EMPLEADO 4
    // =========================================================

    private void procesarTrasladoFinal() {

        Empleado empleado4 =
                obtenerEmpleadoPorId(4);

        if (empleado4 == null) {
            return;
        }


        // -----------------------------------------------------
        // TERMINAR TRASLADO ACTUAL
        // -----------------------------------------------------

        if (trasladoActivo) {

            if (tiempoActual >= finTraslado) {

                /*
                 * Los cuatro llegan juntos
                 * a producto terminado.
                 */
                for (Garrafon garrafon :
                        grupoTraslado) {

                    terminarGarrafon(
                            garrafon
                    );
                }

                grupoTraslado.clear();

                trasladoActivo = false;

                finTraslado = 0;

                empleado4.finalizarActividad(
                        tiempoActual
                );
            }

            return;
        }


        // -----------------------------------------------------
        // COMPROBAR SI HAY GRUPO DE 4
        // -----------------------------------------------------

        if (colaTraslado.size()
                < CAPACIDAD_TRASLADO) {

            return;
        }


        if (!empleado4.estaDisponible()) {
            return;
        }


        // -----------------------------------------------------
        // FORMAR GRUPO
        // -----------------------------------------------------

        grupoTraslado.clear();

        for (int i = 0;
             i < CAPACIDAD_TRASLADO;
             i++) {

            Garrafon garrafon =
                    colaTraslado.poll();

            if (garrafon != null) {

                garrafon.setEstado(
                        EstadoGarrafon
                                .TRASLADO_PRODUCTO_TERMINADO
                );

                grupoTraslado.add(
                        garrafon
                );
            }
        }


        // -----------------------------------------------------
        // EMPLEADO 4 INICIA TRASLADO
        // -----------------------------------------------------

        empleado4.iniciarActividad(
                "Traslado a producto terminado",
                tiempoActual
        );

        trasladoActivo = true;

        finTraslado =
                tiempoActual
                        + TIEMPO_TRASLADO;
    }


    // =========================================================
    // PRODUCTO TERMINADO
    // =========================================================

    public void terminarGarrafon(
            Garrafon garrafon) {

        if (garrafon == null) {
            return;
        }

        garrafon.setEstado(
                EstadoGarrafon.TERMINADO
        );

        garrafon.setTiempoTerminado(
                tiempoActual
        );

        garrafonesTerminados.add(
                garrafon
        );

        totalProcesados++;
    }


    // =========================================================
    // PROCESAR UN SEGUNDO
    // =========================================================

    public void procesarSegundo() {

        if (!ejecutando || pausada) {
            return;
        }

        tiempoActual++;


        // -----------------------------------------------------
        // DESCARGA INICIAL
        // -----------------------------------------------------

        if (descargaInicialActiva) {

            procesarDescargaInicial();

            /*
             * Durante la descarga no avanza
             * ninguna otra etapa.
             */
            return;
        }


        // -----------------------------------------------------
        // CLASIFICACIÓN
        // -----------------------------------------------------

        if (!clasificacionRealizada) {

            clasificarTodosLosGarrafones();
        }


        /*
         * ORDEN DE PRIORIDAD:
         *
         * Llenadora antes de lavado simple:
         * E1 prioriza cargar la máquina cuando
         * existe un grupo completo.
         *
         * Tapado antes de descarga de llenadora
         * se controla mediante disponibilidad E3.
         */

        procesarLlenadora();

        procesarTapadoSellado();

        procesarTrasladoFinal();

        procesarLavadoSimple();

        procesarLavadoProfundo();
    }


    // =========================================================
    // AVANZAR TIEMPO MANUALMENTE
    // =========================================================

    public void avanzarTiempo(
            double segundos) {

        if (!ejecutando) {
            return;
        }

        if (pausada) {
            return;
        }

        if (segundos <= 0) {
            return;
        }

        tiempoActual += segundos;
    }


    // =========================================================
    // PAUSAR
    // =========================================================

    public void pausar() {

        if (!ejecutando) {
            return;
        }

        pausada = true;
    }


    // =========================================================
    // CONTINUAR
    // =========================================================

    public void continuar() {

        if (!ejecutando) {
            return;
        }

        pausada = false;
    }


    // =========================================================
    // FINALIZAR
    // =========================================================

    public void finalizar() {

        ejecutando = false;
        pausada = false;
    }


    // =========================================================
    // REINICIAR
    // =========================================================

    public void reiniciar() {

        reiniciarDatos();

        ejecutando = false;
        pausada = false;
    }


    // =========================================================
    // REINICIAR DATOS
    // =========================================================

    private void reiniciarDatos() {

        tiempoActual = 0;

        totalProcesados = 0;


        // -----------------------------------------------------
        // DESCARGA
        // -----------------------------------------------------

        descargaInicialActiva = false;

        garrafonesDescargados = 0;

        proximoGrupoDescarga = 0;

        clasificacionRealizada = false;


        // -----------------------------------------------------
        // LISTAS Y COLAS
        // -----------------------------------------------------

        garrafones.clear();

        garrafonesTerminados.clear();

        colaRecepcion.clear();

        colaLavadoSimple.clear();

        colaLavadoProfundo.clear();

        colaLlenado.clear();

        colaTapadoSellado.clear();

        colaTraslado.clear();


        // -----------------------------------------------------
        // LAVADOS
        // -----------------------------------------------------

        garrafonLavadoSimple = null;
        finLavadoSimple = 0;

        garrafonLavadoProfundo = null;
        finLavadoProfundo = 0;


        // -----------------------------------------------------
        // LLENADORA
        // -----------------------------------------------------

        grupoLlenadora.clear();

        estadoLlenadora =
                "LIBRE";

        finEtapaLlenadora = 0;


        // -----------------------------------------------------
        // TAPADO Y SELLADO
        // -----------------------------------------------------

        garrafonTapadoSellado = null;

        finTapadoSellado = 0;


        // -----------------------------------------------------
        // TRASLADO FINAL
        // -----------------------------------------------------

        colaTraslado.clear();

        grupoTraslado.clear();

        trasladoActivo = false;

        finTraslado = 0;


        // -----------------------------------------------------
        // EMPLEADOS
        // -----------------------------------------------------

        for (Empleado empleado :
                empleados) {

            empleado.reiniciar();
        }
    }


    // =========================================================
    // CONTAR TIPO DE LAVADO
    // =========================================================

    public int contarTipoLavado(
            TipoLavado tipo) {

        int contador = 0;

        for (Garrafon garrafon :
                garrafones) {

            if (garrafon.getTipoLavado()
                    == tipo) {

                contador++;
            }
        }

        return contador;
    }


    // =========================================================
    // DESCARGA - GETTERS
    // =========================================================

    public boolean isDescargaInicialActiva() {

        return descargaInicialActiva;
    }


    public int getGarrafonesDescargados() {

        return garrafonesDescargados;
    }


    public int getCantidadGrupoDescarga() {

        return CANTIDAD_GRUPO_DESCARGA;
    }


    public double getTiempoGrupoDescarga() {

        return TIEMPO_GRUPO_DESCARGA;
    }


    public double getPorcentajeDescarga() {

        int total =
                parametros.getGarrafonesPorCamion();

        if (total <= 0) {
            return 0;
        }

        return ((double) garrafonesDescargados
                / total) * 100.0;
    }


    public boolean isClasificacionRealizada() {

        return clasificacionRealizada;
    }


    // =========================================================
    // COLAS - GETTERS
    // =========================================================

    public int getCantidadEnRecepcion() {

        return colaRecepcion.size();
    }


    public int getCantidadColaLavadoSimple() {

        return colaLavadoSimple.size();
    }


    public int getCantidadColaLavadoProfundo() {

        return colaLavadoProfundo.size();
    }


    public int getCantidadColaLlenado() {

        return colaLlenado.size();
    }


    public int getCantidadColaTapadoSellado() {

        return colaTapadoSellado.size();
    }


    public int getCantidadColaTraslado() {

        return colaTraslado.size();
    }


    // =========================================================
    // ESTACIONES - GETTERS
    // =========================================================

    public boolean isLavadoSimpleOcupado() {

        return garrafonLavadoSimple != null;
    }


    public boolean isLavadoProfundoOcupado() {

        return garrafonLavadoProfundo != null;
    }


    public String getEstadoLlenadora() {

        return estadoLlenadora;
    }


    public int getCantidadEnLlenadora() {

        return grupoLlenadora.size();
    }


    public boolean isTapadoSelladoOcupado() {

        return garrafonTapadoSellado != null
                || garrafonTapadoSelladoE5 != null;
    }


    // =========================================================
    // TRASLADO FINAL - GETTERS
    // =========================================================

    public boolean isTrasladoActivo() {

        return trasladoActivo;
    }


    public int getCantidadEnTraslado() {

        return grupoTraslado.size();
    }


    public int getCapacidadTraslado() {

        return CAPACIDAD_TRASLADO;
    }


    public double getTiempoTraslado() {

        return TIEMPO_TRASLADO;
    }


    // =========================================================
    // PRODUCTO TERMINADO
    // =========================================================

    public int getCantidadTerminados() {

        return garrafonesTerminados.size();
    }


    public int getTotalProcesados() {

        return totalProcesados;
    }


    public int getCantidadEnSistema() {

        return garrafones.size()
                - garrafonesTerminados.size();
    }


    // =========================================================
    // GETTERS GENERALES
    // =========================================================

    public ParametrosSimulacion getParametros() {

        return parametros;
    }


    public List<Garrafon> getGarrafones() {

        return garrafones;
    }


    public List<Empleado> getEmpleados() {

        return empleados;
    }


    public Queue<Garrafon> getColaRecepcion() {

        return colaRecepcion;
    }


    public Queue<Garrafon> getColaLavadoSimple() {

        return colaLavadoSimple;
    }


    public Queue<Garrafon> getColaLavadoProfundo() {

        return colaLavadoProfundo;
    }


    public Queue<Garrafon> getColaLlenado() {

        return colaLlenado;
    }


    public Queue<Garrafon> getColaTapadoSellado() {

        return colaTapadoSellado;
    }


    public Queue<Garrafon> getColaTraslado() {

        return colaTraslado;
    }


    public List<Garrafon> getGarrafonesTerminados() {

        return garrafonesTerminados;
    }


    public double getTiempoActual() {

        return tiempoActual;
    }


    public boolean isEjecutando() {

        return ejecutando;
    }


    public boolean isPausada() {

        return pausada;
    }
}
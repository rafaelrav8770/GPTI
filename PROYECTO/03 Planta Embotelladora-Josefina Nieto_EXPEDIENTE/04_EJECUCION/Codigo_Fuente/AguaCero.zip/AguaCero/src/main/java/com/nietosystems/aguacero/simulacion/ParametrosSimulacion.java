package com.nietosystems.aguacero.simulacion;

import java.time.Duration;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Parámetros generales utilizados por la simulación
 * de la planta Agua Cero.
 *
 * Todos los tiempos de proceso están expresados
 * en segundos.
 *
 * Esta clase almacena la configuración completa
 * de un escenario de simulación.
 */
public class ParametrosSimulacion {

    // =========================================================
    // IDENTIFICACIÓN DEL ESCENARIO
    // =========================================================

    private String nombreEscenario = "Escenario base";

    private int numeroCorridas = 1;


    // =========================================================
    // PRODUCCIÓN
    // =========================================================

    private int garrafonesPorCamion = 40;

    private int capacidadLlenadora = 4;


    // =========================================================
    // TIPO DE SUCIEDAD
    // =========================================================

    private double porcentajeSemisucio = 70.0;

    private double porcentajeMuySucio = 30.0;


    // =========================================================
    // DESCARGA INICIAL
    // =========================================================

    /**
     * Tiempo requerido para descargar un grupo
     * de cuatro garrafones.
     */
    private double tiempoDescargaInicial = 45.0;


    // =========================================================
    // TIEMPOS DE LAVADO
    // =========================================================

    private double tiempoLavadoSimple = 30.0;

    private double tiempoLavadoProfundo = 60.0;


    // =========================================================
    // LLENADO
    // =========================================================

    /**
     * Se conserva para mantener compatibilidad
     * con el motor actual.
     */
    private double tiempoEsperaInicialLlenado = 120.0;

    private double tiempoCargaLlenadora = 12.0;

    private double tiempoDescargaLlenadora = 12.0;

    private double tiempoProcesoLlenado = 60.0;


    // =========================================================
    // TAPADO Y SELLADO
    // =========================================================

    private double tiempoTapadoSellado = 15.0;


    // =========================================================
    // TRASLADO FINAL
    // =========================================================

    private double tiempoTrasladoFinal = 42.0;


    // =========================================================
    // EMPLEADOS FIJOS
    // COMPATIBILIDAD TEMPORAL
    // =========================================================

    /*
     * Estos campos se conservan temporalmente porque
     * ConfiguracionController todavía trabaja con E1-E5
     * mediante estos métodos.
     *
     * Más adelante podremos retirarlos cuando toda la
     * aplicación utilice la lista dinámica.
     */

    private boolean empleado1Activo = true;
    private boolean empleado2Activo = true;
    private boolean empleado3Activo = true;
    private boolean empleado4Activo = true;
    private boolean empleado5Activo = false;

    private String actividadEmpleado5 = null;


    // =========================================================
    // COSTOS FIJOS
    // COMPATIBILIDAD TEMPORAL
    // =========================================================

    private double costoEmpleado1 = 39.375;
    private double costoEmpleado2 = 39.375;
    private double costoEmpleado3 = 39.375;
    private double costoEmpleado4 = 39.375;
    private double costoEmpleado5 = 39.375;


    // =========================================================
    // LISTA DINÁMICA DE EMPLEADOS
    // =========================================================

    /**
     * Contiene la configuración de los trabajadores
     * del escenario.
     *
     * Esta lista permitirá trabajar con:
     *
     * E1, E2, E3, E4,
     * E5, E6, E7...
     *
     * sin crear variables nuevas para cada empleado.
     */
    private final List<EmpleadoConfiguracion> empleados =
            new ArrayList<>();


    // =========================================================
    // HORARIO LABORAL
    // =========================================================

    private LocalTime horaInicio =
            LocalTime.of(8, 0);

    private LocalTime horaFin =
            LocalTime.of(16, 0);


    // =========================================================
    // CONSTRUCTOR
    // =========================================================

    public ParametrosSimulacion() {

        /*
         * Creamos la estructura base de empleados.
         *
         * Por ahora E1-E4 están activos.
         * E5 se crea también, pero inicialmente desactivado.
         */

        crearEmpleadosBase();
    }


    // =========================================================
    // CREAR EMPLEADOS BASE
    // =========================================================

    private void crearEmpleadosBase() {

        empleados.clear();


        // -----------------------------------------------------
        // EMPLEADO 1
        // -----------------------------------------------------

        EmpleadoConfiguracion empleado1 =
                new EmpleadoConfiguracion(
                        1,
                        "Empleado 1",
                        true,
                        costoEmpleado1
                );

        empleado1.agregarActividad(
                "Descarga inicial"
        );

        empleado1.agregarActividad(
                "Lavado simple"
        );

        empleado1.agregarActividad(
                "Transporte a cola de llenado"
        );

        empleado1.agregarActividad(
                "Carga de llenadora"
        );

        empleados.add(
                empleado1
        );


        // -----------------------------------------------------
        // EMPLEADO 2
        // -----------------------------------------------------

        EmpleadoConfiguracion empleado2 =
                new EmpleadoConfiguracion(
                        2,
                        "Empleado 2",
                        true,
                        costoEmpleado2
                );

        empleado2.agregarActividad(
                "Descarga inicial"
        );

        empleado2.agregarActividad(
                "Lavado profundo"
        );

        empleado2.agregarActividad(
                "Carga de llenadora"
        );

        empleados.add(
                empleado2
        );


        // -----------------------------------------------------
        // EMPLEADO 3
        // -----------------------------------------------------

        EmpleadoConfiguracion empleado3 =
                new EmpleadoConfiguracion(
                        3,
                        "Empleado 3",
                        true,
                        costoEmpleado3
                );

        empleado3.agregarActividad(
                "Descarga de llenadora"
        );

        empleado3.agregarActividad(
                "Tapado y sellado"
        );

        empleados.add(
                empleado3
        );


        // -----------------------------------------------------
        // EMPLEADO 4
        // -----------------------------------------------------

        EmpleadoConfiguracion empleado4 =
                new EmpleadoConfiguracion(
                        4,
                        "Empleado 4",
                        true,
                        costoEmpleado4
                );

        empleado4.agregarActividad(
                "Traslado a producto terminado"
        );

        empleados.add(
                empleado4
        );


        // -----------------------------------------------------
        // EMPLEADO 5
        // -----------------------------------------------------

        EmpleadoConfiguracion empleado5 =
                new EmpleadoConfiguracion(
                        5,
                        "Empleado 5",
                        false,
                        costoEmpleado5
                );

        empleados.add(
                empleado5
        );
    }


    // =========================================================
    // AGREGAR EMPLEADO DINÁMICO
    // =========================================================

    /**
     * Agrega un nuevo empleado al escenario.
     *
     * El ID se obtiene automáticamente.
     *
     * Ejemplo:
     *
     * si existen E1-E5,
     * el siguiente será E6.
     */
    public EmpleadoConfiguracion agregarEmpleado() {

        int nuevoId =
                obtenerSiguienteIdEmpleado();

        EmpleadoConfiguracion nuevoEmpleado =
                new EmpleadoConfiguracion(
                        nuevoId,
                        "Empleado " + nuevoId
                );

        empleados.add(
                nuevoEmpleado
        );

        return nuevoEmpleado;
    }


    // =========================================================
    // AGREGAR EMPLEADO EXISTENTE
    // =========================================================

    public boolean agregarEmpleado(
            EmpleadoConfiguracion empleado) {

        if (empleado == null) {
            return false;
        }

        if (buscarEmpleadoPorId(
                empleado.getId()) != null) {

            return false;
        }

        empleados.add(
                empleado
        );

        return true;
    }


    // =========================================================
    // OBTENER SIGUIENTE ID
    // =========================================================

    private int obtenerSiguienteIdEmpleado() {

        int idMayor = 0;

        for (EmpleadoConfiguracion empleado : empleados) {

            if (empleado.getId() > idMayor) {

                idMayor =
                        empleado.getId();
            }
        }

        return idMayor + 1;
    }


    // =========================================================
    // BUSCAR EMPLEADO POR ID
    // =========================================================

    public EmpleadoConfiguracion buscarEmpleadoPorId(
            int id) {

        for (EmpleadoConfiguracion empleado : empleados) {

            if (empleado.getId() == id) {

                return empleado;
            }
        }

        return null;
    }


    // =========================================================
    // ELIMINAR EMPLEADO
    // =========================================================

    /**
     * Elimina empleados adicionales.
     *
     * Por seguridad, E1-E4 no se eliminan físicamente
     * de la lista. Posteriormente podrán desactivarse
     * para probar escenarios con menos personal.
     */
    public boolean eliminarEmpleado(
            int id) {

        if (id <= 4) {
            return false;
        }

        EmpleadoConfiguracion empleado =
                buscarEmpleadoPorId(id);

        if (empleado == null) {
            return false;
        }

        return empleados.remove(
                empleado
        );
    }


    // =========================================================
    // BUSCAR EMPLEADOS POR ACTIVIDAD
    // =========================================================

    /**
     * Devuelve todos los empleados activos capaces
     * de realizar una actividad.
     */
    public List<EmpleadoConfiguracion>
    buscarEmpleadosParaActividad(
            String actividad) {

        List<EmpleadoConfiguracion> disponibles =
                new ArrayList<>();

        for (EmpleadoConfiguracion empleado : empleados) {

            if (empleado.puedeRealizar(
                    actividad)) {

                disponibles.add(
                        empleado
                );
            }
        }

        return disponibles;
    }


    // =========================================================
    // LISTA DE EMPLEADOS
    // =========================================================

    /**
     * Devuelve una copia de la lista para evitar
     * reemplazos accidentales de la lista interna.
     *
     * Los objetos EmpleadoConfiguracion contenidos
     * siguen siendo los mismos objetos configurables.
     */
    public List<EmpleadoConfiguracion> getEmpleados() {

        return new ArrayList<>(
                empleados
        );
    }


    // =========================================================
    // SINCRONIZAR E1-E5 CON LISTA DINÁMICA
    // =========================================================

    private void sincronizarEmpleadoFijo(
            int id,
            boolean activo,
            double costo) {

        EmpleadoConfiguracion empleado =
                buscarEmpleadoPorId(id);

        if (empleado == null) {
            return;
        }

        empleado.setActivo(
                activo
        );

        empleado.setCostoPorHora(
                costo
        );
    }


    // =========================================================
    // ESCENARIO
    // =========================================================

    public String getNombreEscenario() {
        return nombreEscenario;
    }

    public void setNombreEscenario(
            String nombreEscenario) {

        this.nombreEscenario =
                nombreEscenario;
    }


    public int getNumeroCorridas() {
        return numeroCorridas;
    }

    public void setNumeroCorridas(
            int numeroCorridas) {

        this.numeroCorridas =
                numeroCorridas;
    }


    // =========================================================
    // PRODUCCIÓN
    // =========================================================

    public int getGarrafonesPorCamion() {
        return garrafonesPorCamion;
    }

    public void setGarrafonesPorCamion(
            int garrafonesPorCamion) {

        this.garrafonesPorCamion =
                garrafonesPorCamion;
    }


    public int getCapacidadLlenadora() {
        return capacidadLlenadora;
    }

    public void setCapacidadLlenadora(
            int capacidadLlenadora) {

        this.capacidadLlenadora =
                capacidadLlenadora;
    }


    // =========================================================
    // SUCIEDAD
    // =========================================================

    public double getPorcentajeSemisucio() {
        return porcentajeSemisucio;
    }

    public void setPorcentajeSemisucio(
            double porcentajeSemisucio) {

        this.porcentajeSemisucio =
                porcentajeSemisucio;
    }


    public double getPorcentajeMuySucio() {
        return porcentajeMuySucio;
    }

    public void setPorcentajeMuySucio(
            double porcentajeMuySucio) {

        this.porcentajeMuySucio =
                porcentajeMuySucio;
    }


    // =========================================================
    // DESCARGA
    // =========================================================

    public double getTiempoDescargaInicial() {
        return tiempoDescargaInicial;
    }

    public void setTiempoDescargaInicial(
            double tiempoDescargaInicial) {

        this.tiempoDescargaInicial =
                tiempoDescargaInicial;
    }


    // =========================================================
    // LAVADOS
    // =========================================================

    public double getTiempoLavadoSimple() {
        return tiempoLavadoSimple;
    }

    public void setTiempoLavadoSimple(
            double tiempoLavadoSimple) {

        this.tiempoLavadoSimple =
                tiempoLavadoSimple;
    }


    public double getTiempoLavadoProfundo() {
        return tiempoLavadoProfundo;
    }

    public void setTiempoLavadoProfundo(
            double tiempoLavadoProfundo) {

        this.tiempoLavadoProfundo =
                tiempoLavadoProfundo;
    }


    // =========================================================
    // LLENADO
    // =========================================================

    public double getTiempoEsperaInicialLlenado() {
        return tiempoEsperaInicialLlenado;
    }

    public void setTiempoEsperaInicialLlenado(
            double tiempoEsperaInicialLlenado) {

        this.tiempoEsperaInicialLlenado =
                tiempoEsperaInicialLlenado;
    }


    public double getTiempoCargaLlenadora() {
        return tiempoCargaLlenadora;
    }

    public void setTiempoCargaLlenadora(
            double tiempoCargaLlenadora) {

        this.tiempoCargaLlenadora =
                tiempoCargaLlenadora;
    }


    public double getTiempoDescargaLlenadora() {
        return tiempoDescargaLlenadora;
    }

    public void setTiempoDescargaLlenadora(
            double tiempoDescargaLlenadora) {

        this.tiempoDescargaLlenadora =
                tiempoDescargaLlenadora;
    }


    public double getTiempoProcesoLlenado() {
        return tiempoProcesoLlenado;
    }

    public void setTiempoProcesoLlenado(
            double tiempoProcesoLlenado) {

        this.tiempoProcesoLlenado =
                tiempoProcesoLlenado;
    }


    // =========================================================
    // TAPADO Y SELLADO
    // =========================================================

    public double getTiempoTapadoSellado() {
        return tiempoTapadoSellado;
    }

    public void setTiempoTapadoSellado(
            double tiempoTapadoSellado) {

        this.tiempoTapadoSellado =
                tiempoTapadoSellado;
    }


    // =========================================================
    // TRASLADO FINAL
    // =========================================================

    public double getTiempoTrasladoFinal() {
        return tiempoTrasladoFinal;
    }

    public void setTiempoTrasladoFinal(
            double tiempoTrasladoFinal) {

        this.tiempoTrasladoFinal =
                tiempoTrasladoFinal;
    }


    // =========================================================
    // EMPLEADO 1
    // =========================================================

    public boolean isEmpleado1Activo() {
        return empleado1Activo;
    }

    public void setEmpleado1Activo(
            boolean empleado1Activo) {

        this.empleado1Activo =
                empleado1Activo;

        sincronizarEmpleadoFijo(
                1,
                empleado1Activo,
                costoEmpleado1
        );
    }


    // =========================================================
    // EMPLEADO 2
    // =========================================================

    public boolean isEmpleado2Activo() {
        return empleado2Activo;
    }

    public void setEmpleado2Activo(
            boolean empleado2Activo) {

        this.empleado2Activo =
                empleado2Activo;

        sincronizarEmpleadoFijo(
                2,
                empleado2Activo,
                costoEmpleado2
        );
    }


    // =========================================================
    // EMPLEADO 3
    // =========================================================

    public boolean isEmpleado3Activo() {
        return empleado3Activo;
    }

    public void setEmpleado3Activo(
            boolean empleado3Activo) {

        this.empleado3Activo =
                empleado3Activo;

        sincronizarEmpleadoFijo(
                3,
                empleado3Activo,
                costoEmpleado3
        );
    }


    // =========================================================
    // EMPLEADO 4
    // =========================================================

    public boolean isEmpleado4Activo() {
        return empleado4Activo;
    }

    public void setEmpleado4Activo(
            boolean empleado4Activo) {

        this.empleado4Activo =
                empleado4Activo;

        sincronizarEmpleadoFijo(
                4,
                empleado4Activo,
                costoEmpleado4
        );
    }


    // =========================================================
    // EMPLEADO 5
    // =========================================================

    public boolean isEmpleado5Activo() {
        return empleado5Activo;
    }

    public void setEmpleado5Activo(
            boolean empleado5Activo) {

        this.empleado5Activo =
                empleado5Activo;

        sincronizarEmpleadoFijo(
                5,
                empleado5Activo,
                costoEmpleado5
        );
    }


    public String getActividadEmpleado5() {
        return actividadEmpleado5;
    }


    public void setActividadEmpleado5(
            String actividadEmpleado5) {

        this.actividadEmpleado5 =
                actividadEmpleado5;


        EmpleadoConfiguracion empleado5 =
                buscarEmpleadoPorId(5);

        if (empleado5 == null) {
            return;
        }


        empleado5.limpiarActividades();


        if (actividadEmpleado5 != null
                && !actividadEmpleado5.trim().isEmpty()) {

            empleado5.agregarActividad(
                    actividadEmpleado5
            );
        }
    }


    // =========================================================
    // COSTO EMPLEADO 1
    // =========================================================

    public double getCostoEmpleado1() {
        return costoEmpleado1;
    }

    public void setCostoEmpleado1(
            double costoEmpleado1) {

        this.costoEmpleado1 =
                costoEmpleado1;

        sincronizarEmpleadoFijo(
                1,
                empleado1Activo,
                costoEmpleado1
        );
    }


    // =========================================================
    // COSTO EMPLEADO 2
    // =========================================================

    public double getCostoEmpleado2() {
        return costoEmpleado2;
    }

    public void setCostoEmpleado2(
            double costoEmpleado2) {

        this.costoEmpleado2 =
                costoEmpleado2;

        sincronizarEmpleadoFijo(
                2,
                empleado2Activo,
                costoEmpleado2
        );
    }


    // =========================================================
    // COSTO EMPLEADO 3
    // =========================================================

    public double getCostoEmpleado3() {
        return costoEmpleado3;
    }

    public void setCostoEmpleado3(
            double costoEmpleado3) {

        this.costoEmpleado3 =
                costoEmpleado3;

        sincronizarEmpleadoFijo(
                3,
                empleado3Activo,
                costoEmpleado3
        );
    }


    // =========================================================
    // COSTO EMPLEADO 4
    // =========================================================

    public double getCostoEmpleado4() {
        return costoEmpleado4;
    }

    public void setCostoEmpleado4(
            double costoEmpleado4) {

        this.costoEmpleado4 =
                costoEmpleado4;

        sincronizarEmpleadoFijo(
                4,
                empleado4Activo,
                costoEmpleado4
        );
    }


    // =========================================================
    // COSTO EMPLEADO 5
    // =========================================================

    public double getCostoEmpleado5() {
        return costoEmpleado5;
    }

    public void setCostoEmpleado5(
            double costoEmpleado5) {

        this.costoEmpleado5 =
                costoEmpleado5;

        sincronizarEmpleadoFijo(
                5,
                empleado5Activo,
                costoEmpleado5
        );
    }


    // =========================================================
    // HORARIO
    // =========================================================

    public LocalTime getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(
            LocalTime horaInicio) {

        this.horaInicio =
                horaInicio;
    }


    public LocalTime getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(
            LocalTime horaFin) {

        this.horaFin =
                horaFin;
    }


    // =========================================================
    // DURACIÓN DE LA JORNADA
    // =========================================================

    public int getDuracionJornadaSegundos() {

        if (horaInicio == null
                || horaFin == null) {

            return 0;
        }


        if (!horaFin.isAfter(
                horaInicio)) {

            return 0;
        }


        return (int) Duration.between(
                horaInicio,
                horaFin
        ).getSeconds();
    }


    // =========================================================
    // NÚMERO DE EMPLEADOS ACTIVOS
    // =========================================================

    /**
     * Ahora el número de empleados se obtiene
     * directamente de la lista dinámica.
     */
    public int getNumeroEmpleados() {

        int total = 0;

        for (EmpleadoConfiguracion empleado : empleados) {

            if (empleado.isActivo()) {

                total++;
            }
        }

        return total;
    }


    // =========================================================
    // COSTO TOTAL POR HORA
    // =========================================================

    /**
     * Incluye automáticamente E1, E2, E3...
     * y cualquier empleado adicional creado.
     */
    public double getCostoTotalPorHora() {

        double total = 0.0;

        for (EmpleadoConfiguracion empleado : empleados) {

            if (empleado.isActivo()) {

                total +=
                        empleado.getCostoPorHora();
            }
        }

        return total;
    }


    // =========================================================
    // COSTO DE LA JORNADA
    // =========================================================

    public double getCostoJornada() {

        double horas =
                getDuracionJornadaSegundos()
                        / 3600.0;

        return getCostoTotalPorHora()
                * horas;
    }


    // =========================================================
    // TOTAL DE OBSERVACIONES
    // =========================================================

    /**
     * Permite conocer cuántos garrafones serán
     * observados en todas las corridas.
     *
     * Ejemplo:
     *
     * 40 garrafones x 100 corridas = 4000
     */
    public int getTotalObservaciones() {

        return garrafonesPorCamion
                * numeroCorridas;
    }
}
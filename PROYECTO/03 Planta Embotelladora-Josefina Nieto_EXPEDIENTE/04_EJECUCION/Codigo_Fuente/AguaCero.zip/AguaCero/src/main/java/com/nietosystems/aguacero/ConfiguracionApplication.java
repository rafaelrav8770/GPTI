package com.nietosystems.aguacero;

import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.stage.Screen;
import javafx.stage.Stage;

import java.io.IOException;

public class ConfiguracionApplication {

    public static void mostrar() {

        try {

            FXMLLoader loader = new FXMLLoader(
                    ConfiguracionApplication.class.getResource(
                            "configuracion-view.fxml"
                    )
            );

            Rectangle2D pantallaDisponible =
                    Screen.getPrimary().getVisualBounds();

            Scene scene = new Scene(
                    loader.load(),
                    pantallaDisponible.getWidth(),
                    pantallaDisponible.getHeight()
            );

            /*
             * Ya NO creamos:
             *
             * new Stage()
             *
             * Utilizamos la misma ventana principal.
             */
            Stage stage =
                    MainApplication.getStagePrincipal();

            stage.setTitle(
                    "Agua Cero | Configuración de escenarios"
            );

            stage.setScene(scene);

            stage.setMinWidth(850);
            stage.setMinHeight(600);

            stage.setX(
                    pantallaDisponible.getMinX()
            );

            stage.setY(
                    pantallaDisponible.getMinY()
            );

            stage.setWidth(
                    pantallaDisponible.getWidth()
            );

            stage.setHeight(
                    pantallaDisponible.getHeight()
            );


            /*
             * Si el usuario presiona X estando en
             * Configuración, regresamos al menú principal
             * en lugar de cerrar todo el programa.
             */
            stage.setOnCloseRequest(event -> {

                event.consume();

                MainApplication.mostrarPrincipal();
            });

        } catch (IOException e) {

            System.err.println(
                    "Error al abrir la configuración de Agua Cero."
            );

            e.printStackTrace();
        }
    }
}
package com.nietosystems.aguacero;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class MainApplication extends Application {

    /*
     * Única ventana principal de toda la aplicación.
     */
    private static Stage stagePrincipal;

    @Override
    public void start(Stage stage) throws IOException {

        stagePrincipal = stage;

        mostrarPrincipal();
    }


    // =========================================================
    // MOSTRAR VENTANA PRINCIPAL
    // =========================================================

    public static void mostrarPrincipal() {

        try {

            FXMLLoader loader = new FXMLLoader(
                    MainApplication.class.getResource(
                            "main-view.fxml"
                    )
            );

            Scene scene = new Scene(
                    loader.load(),
                    1100,
                    700
            );

            stagePrincipal.setTitle(
                    "Agua Cero | Simulación de Planta Embotelladora"
            );

            stagePrincipal.setMinWidth(950);
            stagePrincipal.setMinHeight(650);

            stagePrincipal.setScene(scene);

            /*
             * Cuando estamos en la ventana principal,
             * la X cierra normalmente el programa.
             */
            stagePrincipal.setOnCloseRequest(null);

            stagePrincipal.centerOnScreen();

            if (!stagePrincipal.isShowing()) {
                stagePrincipal.show();
            }

        } catch (IOException e) {

            System.err.println(
                    "Error al abrir la ventana principal."
            );

            e.printStackTrace();
        }
    }


    // =========================================================
    // OBTENER STAGE PRINCIPAL
    // =========================================================

    public static Stage getStagePrincipal() {
        return stagePrincipal;
    }


    public static void main(String[] args) {
        launch();
    }
}
package com.nietosystems.aguacero.controller;

import com.nietosystems.aguacero.simulacion.ParametrosSimulacion;
import com.nietosystems.aguacero.SimulacionApplication;
import com.nietosystems.aguacero.MainApplication;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class ConfiguracionController {

    // =========================================================
    // CONFIGURACIÓN GUARDADA PARA LA SIMULACIÓN
    // =========================================================

    private static ParametrosSimulacion parametrosGuardados;

    public static ParametrosSimulacion getParametrosGuardados() {
        return parametrosGuardados;
    }

    // =========================================================
    // DATOS GENERALES
    // =========================================================

    @FXML
    private TextField txtNombreEscenario;

    @FXML
    private TextField txtGarrafones;

    @FXML
    private TextField txtCorridas;

    @FXML
    private TextField txtHoraInicio;

    @FXML
    private TextField txtHoraCierre;


    // =========================================================
    // PARÁMETROS DEL PROCESO
    // =========================================================

    @FXML
    private TextField txtTiempoDescarga;

    @FXML
    private TextField txtLavadoSimple;

    @FXML
    private TextField txtLavadoProfundo;

    @FXML
    private TextField txtCargaLlenadora;

    @FXML
    private TextField txtTiempoLlenado;

    @FXML
    private TextField txtDescargaLlenadora;

    @FXML
    private TextField txtTapadoSellado;

    @FXML
    private TextField txtTrasladoFinal;


    // =========================================================
    // EMPLEADOS
    // =========================================================

    @FXML
    private CheckBox chkEmpleado1;

    @FXML
    private CheckBox chkEmpleado2;

    @FXML
    private CheckBox chkEmpleado3;

    @FXML
    private CheckBox chkEmpleado4;

    @FXML
    private CheckBox chkEmpleado5;


    // =========================================================
    // COSTOS
    // =========================================================

    @FXML
    private TextField txtCostoEmpleado1;

    @FXML
    private TextField txtCostoEmpleado2;

    @FXML
    private TextField txtCostoEmpleado3;

    @FXML
    private TextField txtCostoEmpleado4;

    @FXML
    private TextField txtCostoEmpleado5;


    // =========================================================
    // VALIDACIÓN
    // =========================================================

    @FXML
    private Label lblValidacion;


    // =========================================================
    // BOTONES
    // =========================================================

    @FXML
    private Button btnRestaurar;

    @FXML
    private Button btnGuardar;

    @FXML
    private Button btnContinuar;


    // =========================================================
    // FORMATO DE HORA
    // =========================================================

    private final DateTimeFormatter formatoHora =
            DateTimeFormatter.ofPattern("HH:mm");


    // =========================================================
    // INICIALIZACIÓN
    // =========================================================

    @FXML
    public void initialize() {

        /*
         * Carga los valores base del escenario al abrir la ventana.
         * Los costos comienzan en $39.375 por hora, pero continúan
         * siendo completamente editables por el usuario.
         */
        restaurarValores();

        configurarEventos();

        mostrarValidacionPendiente();
    }

    @FXML
    protected void onRegresarClick() {

        /*
         * Regresa a la pantalla principal utilizando
         * la misma ventana de la aplicación.
         */
        MainApplication.mostrarPrincipal();
    }




    // =========================================================
    // EVENTOS
    // =========================================================

    private void configurarEventos() {

        btnRestaurar.setOnAction(
                event -> restaurarValores()
        );

        btnGuardar.setOnAction(
                event -> guardarConfiguracion()
        );

        btnContinuar.setOnAction(
                event -> continuarSimulacion()
        );

        chkEmpleado5.setOnAction(
                event -> configurarEmpleado5()
        );


        // Si el usuario cambia algún dato importante,
        // la configuración guardada deja de representar
        // exactamente lo que aparece en pantalla.

        txtNombreEscenario.textProperty().addListener(
                (obs, anterior, nuevo) -> marcarComoModificada()
        );

        txtGarrafones.textProperty().addListener(
                (obs, anterior, nuevo) -> marcarComoModificada()
        );

        txtCorridas.textProperty().addListener(
                (obs, anterior, nuevo) -> marcarComoModificada()
        );

        txtHoraInicio.textProperty().addListener(
                (obs, anterior, nuevo) -> marcarComoModificada()
        );

        txtHoraCierre.textProperty().addListener(
                (obs, anterior, nuevo) -> marcarComoModificada()
        );


        txtTiempoDescarga.textProperty().addListener(
                (obs, anterior, nuevo) -> marcarComoModificada()
        );

        txtLavadoSimple.textProperty().addListener(
                (obs, anterior, nuevo) -> marcarComoModificada()
        );

        txtLavadoProfundo.textProperty().addListener(
                (obs, anterior, nuevo) -> marcarComoModificada()
        );

        txtCargaLlenadora.textProperty().addListener(
                (obs, anterior, nuevo) -> marcarComoModificada()
        );

        txtTiempoLlenado.textProperty().addListener(
                (obs, anterior, nuevo) -> marcarComoModificada()
        );

        txtDescargaLlenadora.textProperty().addListener(
                (obs, anterior, nuevo) -> marcarComoModificada()
        );

        txtTapadoSellado.textProperty().addListener(
                (obs, anterior, nuevo) -> marcarComoModificada()
        );

        txtTrasladoFinal.textProperty().addListener(
                (obs, anterior, nuevo) -> marcarComoModificada()
        );


        txtCostoEmpleado1.textProperty().addListener(
                (obs, anterior, nuevo) -> marcarComoModificada()
        );

        txtCostoEmpleado2.textProperty().addListener(
                (obs, anterior, nuevo) -> marcarComoModificada()
        );

        txtCostoEmpleado3.textProperty().addListener(
                (obs, anterior, nuevo) -> marcarComoModificada()
        );

        txtCostoEmpleado4.textProperty().addListener(
                (obs, anterior, nuevo) -> marcarComoModificada()
        );

        txtCostoEmpleado5.textProperty().addListener(
                (obs, anterior, nuevo) -> marcarComoModificada()
        );


        chkEmpleado1.selectedProperty().addListener(
                (obs, anterior, nuevo) -> marcarComoModificada()
        );

        chkEmpleado2.selectedProperty().addListener(
                (obs, anterior, nuevo) -> marcarComoModificada()
        );

        chkEmpleado3.selectedProperty().addListener(
                (obs, anterior, nuevo) -> marcarComoModificada()
        );

        chkEmpleado4.selectedProperty().addListener(
                (obs, anterior, nuevo) -> marcarComoModificada()
        );
    }



    // =========================================================
    // CONFIGURAR EMPLEADO 5
    // =========================================================

    private void configurarEmpleado5() {

        boolean activo = chkEmpleado5.isSelected();

        /*
         * E5 es opcional. Cuando está desactivado, el campo de costo
         * permanece bloqueado, pero conserva el valor base de $39.375.
         * Al activarlo, el usuario puede modificar libremente el costo.
         */
        txtCostoEmpleado5.setDisable(!activo);

        if (txtCostoEmpleado5.getText() == null
                || txtCostoEmpleado5.getText().trim().isEmpty()) {

            txtCostoEmpleado5.setText("39.375");
        }

        marcarComoModificada();
    }

    // =========================================================
    // MARCAR CONFIGURACIÓN COMO MODIFICADA
    // =========================================================

    private void marcarComoModificada() {

        parametrosGuardados = null;

        mostrarValidacionPendiente();
    }


    // =========================================================
    // RESTAURAR VALORES
    // =========================================================

    private void restaurarValores() {

        txtNombreEscenario.setText(
                "Escenario base"
        );

        txtGarrafones.setText(
                "40"
        );

        txtCorridas.setText(
                "1"
        );

        txtHoraInicio.setText(
                "08:00"
        );

        txtHoraCierre.setText(
                "16:00"
        );


        // -----------------------------------------------------
        // TIEMPOS
        // -----------------------------------------------------

        txtTiempoDescarga.setText(
                "45"
        );

        txtLavadoSimple.setText(
                "30"
        );

        txtLavadoProfundo.setText(
                "60"
        );

        txtCargaLlenadora.setText(
                "12"
        );

        txtTiempoLlenado.setText(
                "60"
        );

        txtDescargaLlenadora.setText(
                "12"
        );

        txtTapadoSellado.setText(
                "15"
        );

        txtTrasladoFinal.setText(
                "42"
        );


        // -----------------------------------------------------
        // PERSONAL
        // -----------------------------------------------------

        chkEmpleado1.setSelected(
                true
        );

        chkEmpleado2.setSelected(
                true
        );

        chkEmpleado3.setSelected(
                true
        );

        chkEmpleado4.setSelected(
                true
        );

        chkEmpleado5.setSelected(
                false
        );


        // -----------------------------------------------------
        // COSTOS
        // -----------------------------------------------------

        txtCostoEmpleado1.setText(
                "39.375"
        );

        txtCostoEmpleado2.setText(
                "39.375"
        );

        txtCostoEmpleado3.setText(
                "39.375"
        );

        txtCostoEmpleado4.setText(
                "39.375"
        );

        txtCostoEmpleado5.setText(
                "39.375"
        );
        configurarEmpleado5();

        parametrosGuardados = null;

        mostrarValidacionPendiente();
    }


    // =========================================================
    // GUARDAR CONFIGURACIÓN
    // =========================================================

    private void guardarConfiguracion() {

        if (!validarConfiguracion()) {
            return;
        }

        parametrosGuardados =
                crearParametrosDesdeFormulario();

        mostrarValidacionCorrecta();


        // -----------------------------------------------------
        // MENSAJE DE CONFIRMACIÓN
        // -----------------------------------------------------

        Alert alerta =
                new Alert(
                        Alert.AlertType.INFORMATION
                );

        alerta.setTitle(
                "Agua Cero"
        );

        alerta.setHeaderText(
                "Configuración guardada correctamente"
        );

        alerta.setContentText(
                construirResumen(parametrosGuardados)
        );

        alerta.showAndWait();
    }


    // =========================================================
    // CREAR PARAMETROS SIMULACION
    // =========================================================

    private ParametrosSimulacion crearParametrosDesdeFormulario() {

        ParametrosSimulacion parametros =
                new ParametrosSimulacion();


        // -----------------------------------------------------
        // ESCENARIO
        // -----------------------------------------------------

        parametros.setNombreEscenario(
                txtNombreEscenario.getText().trim()
        );

        parametros.setNumeroCorridas(
                Integer.parseInt(
                        txtCorridas.getText().trim()
                )
        );


        // -----------------------------------------------------
        // PRODUCCIÓN
        // -----------------------------------------------------

        parametros.setGarrafonesPorCamion(
                Integer.parseInt(
                        txtGarrafones.getText().trim()
                )
        );


        /*
         * La llenadora permanece trabajando con grupos
         * de cuatro garrafones.
         */
        parametros.setCapacidadLlenadora(
                4
        );


        // -----------------------------------------------------
        // CLASIFICACIÓN
        // -----------------------------------------------------

        /*
         * Conservamos por ahora la distribución base:
         *
         * 70 % lavado simple
         * 30 % lavado profundo
         *
         * Para 40 garrafones:
         *
         * 28 simples
         * 12 profundos
         */
        parametros.setPorcentajeSemisucio(
                70.0
        );

        parametros.setPorcentajeMuySucio(
                30.0
        );


        // -----------------------------------------------------
        // TIEMPOS
        // -----------------------------------------------------

        parametros.setTiempoDescargaInicial(
                Double.parseDouble(
                        txtTiempoDescarga.getText().trim()
                )
        );

        parametros.setTiempoLavadoSimple(
                Double.parseDouble(
                        txtLavadoSimple.getText().trim()
                )
        );

        parametros.setTiempoLavadoProfundo(
                Double.parseDouble(
                        txtLavadoProfundo.getText().trim()
                )
        );

        parametros.setTiempoCargaLlenadora(
                Double.parseDouble(
                        txtCargaLlenadora.getText().trim()
                )
        );

        parametros.setTiempoProcesoLlenado(
                Double.parseDouble(
                        txtTiempoLlenado.getText().trim()
                )
        );

        parametros.setTiempoDescargaLlenadora(
                Double.parseDouble(
                        txtDescargaLlenadora.getText().trim()
                )
        );

        parametros.setTiempoTapadoSellado(
                Double.parseDouble(
                        txtTapadoSellado.getText().trim()
                )
        );

        parametros.setTiempoTrasladoFinal(
                Double.parseDouble(
                        txtTrasladoFinal.getText().trim()
                )
        );


        // -----------------------------------------------------
        // HORARIO
        // -----------------------------------------------------

        parametros.setHoraInicio(
                LocalTime.parse(
                        txtHoraInicio.getText().trim(),
                        formatoHora
                )
        );

        parametros.setHoraFin(
                LocalTime.parse(
                        txtHoraCierre.getText().trim(),
                        formatoHora
                )
        );


        // -----------------------------------------------------
        // EMPLEADOS ACTIVOS
        // -----------------------------------------------------

        parametros.setEmpleado1Activo(
                chkEmpleado1.isSelected()
        );

        parametros.setEmpleado2Activo(
                chkEmpleado2.isSelected()
        );

        parametros.setEmpleado3Activo(
                chkEmpleado3.isSelected()
        );

        parametros.setEmpleado4Activo(
                chkEmpleado4.isSelected()
        );

        parametros.setEmpleado5Activo(
                chkEmpleado5.isSelected()
        );


        // -----------------------------------------------------
        // EMPLEADO 5
        // -----------------------------------------------------

        if (chkEmpleado5.isSelected()) {
            parametros.setActividadEmpleado5("Tapado y sellado");
        } else {
            parametros.setActividadEmpleado5(null);
        }


        // -----------------------------------------------------
        // COSTOS
        // -----------------------------------------------------

        parametros.setCostoEmpleado1(
                convertirCosto(
                        txtCostoEmpleado1.getText()
                )
        );

        parametros.setCostoEmpleado2(
                convertirCosto(
                        txtCostoEmpleado2.getText()
                )
        );

        parametros.setCostoEmpleado3(
                convertirCosto(
                        txtCostoEmpleado3.getText()
                )
        );

        parametros.setCostoEmpleado4(
                convertirCosto(
                        txtCostoEmpleado4.getText()
                )
        );


        if (chkEmpleado5.isSelected()) {

            parametros.setCostoEmpleado5(
                    convertirCosto(
                            txtCostoEmpleado5.getText()
                    )
            );

        } else {

            parametros.setCostoEmpleado5(
                    0.0
            );
        }



        return parametros;
    }


    // =========================================================
    // CONTINUAR A SIMULACIÓN
    // =========================================================

    private void continuarSimulacion() {

        /*
         * Si el usuario todavía no guardó o modificó algo
         * después de guardar, volvemos a validar y crear
         * los parámetros.
         */
        if (parametrosGuardados == null) {

            if (!validarConfiguracion()) {
                return;
            }

            parametrosGuardados =
                    crearParametrosDesdeFormulario();

            mostrarValidacionCorrecta();
        }


        // =========================================================
        // CONFIRMACIÓN
        // =========================================================

        Alert alerta =
                new Alert(
                        Alert.AlertType.INFORMATION
                );

        alerta.setTitle(
                "Agua Cero"
        );

        alerta.setHeaderText(
                "Escenario preparado para simulación"
        );

        alerta.setContentText(
                construirResumen(parametrosGuardados)
                        + "\n\n"
                        + "Los parámetros ya están almacenados "
                        + "y listos para utilizarse en la simulación."
        );


        /*
         * Esperamos a que el usuario cierre
         * el cuadro de confirmación.
         */
        alerta.showAndWait();


        // =========================================================
        // ABRIR SIMULACIÓN
        // =========================================================

        /*
         * Utiliza el mismo Stage principal.
         * Configuración desaparece y en su lugar
         * se muestra la pantalla de simulación.
         */
        SimulacionApplication.mostrar();
    }


    // =========================================================
    // RESUMEN
    // =========================================================

    private String construirResumen(
            ParametrosSimulacion parametros) {

        StringBuilder resumen =
                new StringBuilder();

        resumen.append(
                "Escenario: "
        );

        resumen.append(
                parametros.getNombreEscenario()
        );

        resumen.append(
                "\n"
        );


        resumen.append(
                "Garrafones por lote: "
        );

        resumen.append(
                parametros.getGarrafonesPorCamion()
        );

        resumen.append(
                "\n"
        );


        resumen.append(
                "Corridas: "
        );

        resumen.append(
                parametros.getNumeroCorridas()
        );

        resumen.append(
                "\n"
        );


        resumen.append(
                "Horario: "
        );

        resumen.append(
                parametros.getHoraInicio()
        );

        resumen.append(
                " - "
        );

        resumen.append(
                parametros.getHoraFin()
        );

        resumen.append(
                "\n"
        );


        resumen.append(
                "Empleados activos: "
        );

        resumen.append(
                parametros.getNumeroEmpleados()
        );

        resumen.append(
                "\n"
        );


        resumen.append(
                "Costo total por hora: $"
        );

        resumen.append(
                String.format(
                        "%.2f",
                        parametros.getCostoTotalPorHora()
                )
        );

        resumen.append(
                "\n"
        );


        resumen.append(
                "Costo de la jornada: $"
        );

        resumen.append(
                String.format(
                        "%.2f",
                        parametros.getCostoJornada()
                )
        );


        if (parametros.isEmpleado5Activo()) {

            resumen.append(
                    "\n"
            );

            resumen.append(
                    "Empleado 5: "
            );

            resumen.append(
                    "Apoyo en Tapado y sellado"
            );
        }


        return resumen.toString();
    }


    // =========================================================
    // CONVERTIR COSTO
    // =========================================================

    private double convertirCosto(
            String texto) {

        return Double.parseDouble(
                texto.trim()
                        .replace(",", ".")
        );
    }


    // =========================================================
    // VALIDAR CONFIGURACIÓN
    // =========================================================

    private boolean validarConfiguracion() {

        // -----------------------------------------------------
        // NOMBRE
        // -----------------------------------------------------

        if (txtNombreEscenario
                .getText()
                .trim()
                .isEmpty()) {

            mostrarError(
                    "Nombre del escenario",
                    "Escribe un nombre para identificar el escenario."
            );

            return false;
        }


        // -----------------------------------------------------
        // GARRAFONES
        // -----------------------------------------------------

        Integer garrafones =
                obtenerEnteroPositivo(
                        txtGarrafones,
                        "Garrafones por lote"
                );

        if (garrafones == null) {
            return false;
        }


        if (garrafones % 4 != 0) {

            mostrarError(
                    "Garrafones por lote",
                    "La cantidad debe ser múltiplo de 4, "
                            + "porque la llenadora trabaja "
                            + "con grupos de cuatro garrafones."
            );

            return false;
        }


        // -----------------------------------------------------
        // CORRIDAS
        // -----------------------------------------------------

        if (obtenerEnteroPositivo(
                txtCorridas,
                "Número de corridas"
        ) == null) {

            return false;
        }


        // -----------------------------------------------------
        // HORARIO
        // -----------------------------------------------------

        LocalTime horaInicio =
                obtenerHora(
                        txtHoraInicio,
                        "Hora de inicio"
                );

        if (horaInicio == null) {
            return false;
        }


        LocalTime horaCierre =
                obtenerHora(
                        txtHoraCierre,
                        "Hora de cierre"
                );

        if (horaCierre == null) {
            return false;
        }


        if (!horaCierre.isAfter(horaInicio)) {

            mostrarError(
                    "Horario de jornada",
                    "La hora de cierre debe ser posterior "
                            + "a la hora de inicio."
            );

            return false;
        }


        // -----------------------------------------------------
        // TIEMPOS
        // -----------------------------------------------------

        if (obtenerEnteroPositivo(
                txtTiempoDescarga,
                "Tiempo de descarga inicial"
        ) == null) {
            return false;
        }

        if (obtenerEnteroPositivo(
                txtLavadoSimple,
                "Tiempo de lavado simple"
        ) == null) {
            return false;
        }

        if (obtenerEnteroPositivo(
                txtLavadoProfundo,
                "Tiempo de lavado profundo"
        ) == null) {
            return false;
        }

        if (obtenerEnteroPositivo(
                txtCargaLlenadora,
                "Tiempo de carga de llenadora"
        ) == null) {
            return false;
        }

        if (obtenerEnteroPositivo(
                txtTiempoLlenado,
                "Tiempo del ciclo de llenado"
        ) == null) {
            return false;
        }

        if (obtenerEnteroPositivo(
                txtDescargaLlenadora,
                "Tiempo de descarga de llenadora"
        ) == null) {
            return false;
        }

        if (obtenerEnteroPositivo(
                txtTapadoSellado,
                "Tiempo de tapado y sellado"
        ) == null) {
            return false;
        }

        if (obtenerEnteroPositivo(
                txtTrasladoFinal,
                "Tiempo de traslado final"
        ) == null) {
            return false;
        }


        // -----------------------------------------------------
        // EMPLEADOS
        // -----------------------------------------------------

        if (!chkEmpleado1.isSelected()
                && !chkEmpleado2.isSelected()
                && !chkEmpleado3.isSelected()
                && !chkEmpleado4.isSelected()
                && !chkEmpleado5.isSelected()) {

            mostrarError(
                    "Personal",
                    "Debe existir al menos un empleado activo."
            );

            return false;
        }


        /*
         * ALCANCE FINAL DEL PROYECTO:
         *
         * E1, E2, E3 y E4 forman el personal base de la planta.
         * E5 es un apoyo opcional exclusivamente para
         * Tapado y sellado.
         */

        if (!chkEmpleado1.isSelected()) {

            mostrarError(
                    "Empleado 1",
                    "Por ahora E1 debe permanecer activo "
                            + "porque el motor actual depende "
                            + "de sus actividades."
            );

            return false;
        }


        if (!chkEmpleado2.isSelected()) {

            mostrarError(
                    "Empleado 2",
                    "Por ahora E2 debe permanecer activo "
                            + "porque realiza el lavado profundo."
            );

            return false;
        }


        if (!chkEmpleado3.isSelected()) {

            mostrarError(
                    "Empleado 3",
                    "Por ahora E3 debe permanecer activo "
                            + "porque realiza la descarga de "
                            + "la llenadora y tapado/sellado."
            );

            return false;
        }


        if (!chkEmpleado4.isSelected()) {

            mostrarError(
                    "Empleado 4",
                    "Por ahora E4 debe permanecer activo "
                            + "porque realiza el traslado final."
            );

            return false;
        }



        // -----------------------------------------------------
        // COSTOS
        // -----------------------------------------------------

        if (!validarCosto(
                txtCostoEmpleado1,
                "Costo del Empleado 1"
        )) {
            return false;
        }

        if (!validarCosto(
                txtCostoEmpleado2,
                "Costo del Empleado 2"
        )) {
            return false;
        }

        if (!validarCosto(
                txtCostoEmpleado3,
                "Costo del Empleado 3"
        )) {
            return false;
        }

        if (!validarCosto(
                txtCostoEmpleado4,
                "Costo del Empleado 4"
        )) {
            return false;
        }


        if (chkEmpleado5.isSelected()) {

            if (!validarCosto(
                    txtCostoEmpleado5,
                    "Costo del Empleado 5"
            )) {

                return false;
            }
        }


        return true;
    }


    // =========================================================
    // ENTERO POSITIVO
    // =========================================================

    private Integer obtenerEnteroPositivo(
            TextField campo,
            String nombreCampo) {

        String texto =
                campo.getText().trim();

        if (texto.isEmpty()) {

            mostrarError(
                    nombreCampo,
                    "El campo no puede quedar vacío."
            );

            campo.requestFocus();

            return null;
        }


        try {

            int valor =
                    Integer.parseInt(texto);

            if (valor <= 0) {

                mostrarError(
                        nombreCampo,
                        "El valor debe ser mayor que cero."
                );

                campo.requestFocus();

                return null;
            }

            return valor;

        } catch (NumberFormatException e) {

            mostrarError(
                    nombreCampo,
                    "Ingresa únicamente un número entero válido."
            );

            campo.requestFocus();

            return null;
        }
    }


    // =========================================================
    // VALIDAR COSTO
    // =========================================================

    private boolean validarCosto(
            TextField campo,
            String nombreCampo) {

        String texto =
                campo.getText()
                        .trim()
                        .replace(",", ".");

        if (texto.isEmpty()) {

            mostrarError(
                    nombreCampo,
                    "Ingresa el costo por hora. "
                            + "Si todavía no deseas asignarlo, "
                            + "utiliza 0.00."
            );

            campo.requestFocus();

            return false;
        }


        try {

            double costo =
                    Double.parseDouble(texto);

            if (costo < 0) {

                mostrarError(
                        nombreCampo,
                        "El costo no puede ser negativo."
                );

                campo.requestFocus();

                return false;
            }

            return true;

        } catch (NumberFormatException e) {

            mostrarError(
                    nombreCampo,
                    "Ingresa un costo válido. Ejemplo: 45.50"
            );

            campo.requestFocus();

            return false;
        }
    }


    // =========================================================
    // OBTENER HORA
    // =========================================================

    private LocalTime obtenerHora(
            TextField campo,
            String nombreCampo) {

        String texto =
                campo.getText().trim();

        try {

            return LocalTime.parse(
                    texto,
                    formatoHora
            );

        } catch (DateTimeParseException e) {

            mostrarError(
                    nombreCampo,
                    "Utiliza el formato de 24 horas HH:mm.\n"
                            + "Ejemplo: 08:00 o 16:00."
            );

            campo.requestFocus();

            return null;
        }
    }


    // =========================================================
    // VALIDACIÓN PENDIENTE
    // =========================================================

    private void mostrarValidacionPendiente() {

        if (lblValidacion == null) {
            return;
        }

        lblValidacion.setText(
                "● Configuración pendiente de validación"
        );

        lblValidacion.setStyle(
                "-fx-font-size: 13px;"
                        + "-fx-font-weight: bold;"
                        + "-fx-text-fill: #B45309;"
        );
    }


    // =========================================================
    // VALIDACIÓN CORRECTA
    // =========================================================

    private void mostrarValidacionCorrecta() {

        lblValidacion.setText(
                "✓ Escenario válido y configuración guardada"
        );

        lblValidacion.setStyle(
                "-fx-font-size: 13px;"
                        + "-fx-font-weight: bold;"
                        + "-fx-text-fill: #166534;"
        );
    }


    // =========================================================
    // ERROR
    // =========================================================

    private void mostrarError(
            String titulo,
            String mensaje) {

        lblValidacion.setText(
                "✕ Se encontraron datos que requieren corrección"
        );

        lblValidacion.setStyle(
                "-fx-font-size: 13px;"
                        + "-fx-font-weight: bold;"
                        + "-fx-text-fill: #B91C1C;"
        );


        Alert alerta =
                new Alert(
                        Alert.AlertType.WARNING
                );

        alerta.setTitle(
                "Validación de escenario"
        );

        alerta.setHeaderText(
                titulo
        );

        alerta.setContentText(
                mensaje
        );

        alerta.showAndWait();
    }

}

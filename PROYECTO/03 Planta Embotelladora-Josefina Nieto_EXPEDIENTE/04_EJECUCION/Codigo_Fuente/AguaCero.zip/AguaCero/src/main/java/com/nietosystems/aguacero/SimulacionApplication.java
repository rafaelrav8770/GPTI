package com.nietosystems.aguacero;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class SimulacionApplication {

    public static void mostrar() {

        try {

            FXMLLoader loader = new FXMLLoader(
                    SimulacionApplication.class.getResource(
                            "simulacion-view.fxml"
                    )
            );

            Scene scene = new Scene(
                    loader.load(),
                    1200,
                    720
            );

            /*
             * Utilizamos la misma ventana de toda
             * la aplicación.
             */
            Stage stage =
                    MainApplication.getStagePrincipal();

            stage.setTitle(
                    "Agua Cero | Simulación de Planta"
            );

            stage.setResizable(true);

            stage.setMinWidth(850);
            stage.setMinHeight(450);

            stage.setScene(scene);

            stage.centerOnScreen();


            /*
             * Si se presiona X desde Simulación,
             * regresamos a la pantalla principal.
             */
            stage.setOnCloseRequest(event -> {

                event.consume();

                MainApplication.mostrarPrincipal();
            });

        } catch (IOException e) {

            System.err.println(
                    "Error al abrir la simulación de Agua Cero."
            );

            e.printStackTrace();
        }
    }
}
package com.nietosystems.aguacero;

import com.nietosystems.aguacero.simulacion.MotorSimulacion;
import com.nietosystems.aguacero.simulacion.ParametrosSimulacion;
import com.nietosystems.aguacero.simulacion.TipoLavado;

import javafx.stage.FileChooser;
import javafx.stage.Window;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Exporta los resultados de la última corrida de Agua Cero
 * a PDF y Excel.
 *
 * La clase trabaja directamente con MotorSimulacion, por lo que
 * los archivos reflejan los parámetros y resultados reales
 * de la corrida que se está consultando.
 */
public final class ExportadorResultados {

    private static final DateTimeFormatter FECHA_ARCHIVO =
            DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm");

    private static final DateTimeFormatter FECHA_REPORTE =
            DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private ExportadorResultados() {
        // Clase utilitaria: no necesita instancias.
    }


    // =========================================================
    // EXPORTAR PDF
    // =========================================================

    public static File exportarPDF(
            MotorSimulacion motor,
            Window ventanaPropietaria) throws IOException {

        validarMotor(motor);

        FileChooser selector = new FileChooser();

        selector.setTitle(
                "Guardar reporte PDF - Agua Cero"
        );

        selector.getExtensionFilters().add(
                new FileChooser.ExtensionFilter(
                        "Archivo PDF (*.pdf)",
                        "*.pdf"
                )
        );

        selector.setInitialFileName(
                "Reporte_AguaCero_"
                        + LocalDateTime.now()
                        .format(FECHA_ARCHIVO)
                        + ".pdf"
        );

        File archivo =
                selector.showSaveDialog(
                        ventanaPropietaria
                );

        if (archivo == null) {
            return null;
        }

        archivo = asegurarExtension(
                archivo,
                ".pdf"
        );

        crearPDF(
                motor,
                archivo
        );

        return archivo;
    }


    private static void crearPDF(
            MotorSimulacion motor,
            File archivo) throws IOException {

        ParametrosSimulacion parametros =
                motor.getParametros();

        double tiempoSegundos =
                motor.getTiempoActual();

        int terminados =
                motor.getCantidadTerminados();

        int total =
                motor.getTotalProcesados();

        int simples =
                motor.contarTipoLavado(
                        TipoLavado.SIMPLE
                );

        int profundos =
                motor.contarTipoLavado(
                        TipoLavado.PROFUNDO
                );

        double productividad =
                calcularProductividad(
                        terminados,
                        tiempoSegundos
                );

        double costoHora =
                parametros.getCostoTotalPorHora();

        double costoPersonal =
                costoHora
                        * (tiempoSegundos / 3600.0);

        double costoGarrafon =
                terminados > 0
                        ? costoPersonal / terminados
                        : 0.0;

        // =====================================================
        // PROYECCIÓN DEL ESCENARIO
        // =====================================================

        int numeroCorridas =
                Math.max(
                        1,
                        parametros.getNumeroCorridas()
                );

        long garrafonesProyectados =
                (long) terminados
                        * numeroCorridas;

        double tiempoProyectadoSegundos =
                tiempoSegundos
                        * numeroCorridas;

        double horasProyectadas =
                tiempoProyectadoSegundos
                        / 3600.0;

        double jornadasEquivalentes =
                horasProyectadas
                        / 8.0;

        double costoLaboralProyectado =
                costoHora
                        * horasProyectadas;

        double costoGarrafonProyectado =
                garrafonesProyectados > 0
                        ? costoLaboralProyectado / garrafonesProyectados
                        : 0.0;

        try (PDDocument documento =
                     new PDDocument()) {

            PDPage pagina =
                    new PDPage(
                            PDRectangle.LETTER
                    );

            documento.addPage(
                    pagina
            );

            PDType1Font fuenteNormal =
                    new PDType1Font(
                            Standard14Fonts.FontName.HELVETICA
                    );

            PDType1Font fuenteNegrita =
                    new PDType1Font(
                            Standard14Fonts.FontName.HELVETICA_BOLD
                    );

            try (PDPageContentStream contenido =
                         new PDPageContentStream(
                                 documento,
                                 pagina
                         )) {

                float x = 55;
                float y = 735;

                y = escribirLinea(
                        contenido,
                        fuenteNegrita,
                        18,
                        x,
                        y,
                        "AGUA CERO"
                );

                y = escribirLinea(
                        contenido,
                        fuenteNegrita,
                        13,
                        x,
                        y,
                        "Reporte de resultados y estadisticas"
                );

                y -= 5;

                y = escribirLinea(
                        contenido,
                        fuenteNormal,
                        10,
                        x,
                        y,
                        "Generado: "
                                + LocalDateTime.now()
                                .format(FECHA_REPORTE)
                );

                y -= 12;

                y = escribirLinea(
                        contenido,
                        fuenteNegrita,
                        12,
                        x,
                        y,
                        "1. Resultados generales"
                );

                y = escribirDatoPDF(
                        contenido,
                        fuenteNormal,
                        x,
                        y,
                        "Garrafones procesados",
                        String.valueOf(total)
                );

                y = escribirDatoPDF(
                        contenido,
                        fuenteNormal,
                        x,
                        y,
                        "Garrafones terminados",
                        String.valueOf(terminados)
                );

                y = escribirDatoPDF(
                        contenido,
                        fuenteNormal,
                        x,
                        y,
                        "Tiempo total",
                        formatoTiempo(tiempoSegundos)
                );

                y = escribirDatoPDF(
                        contenido,
                        fuenteNormal,
                        x,
                        y,
                        "Productividad",
                        String.format(
                                "%.2f garrafones/h",
                                productividad
                        )
                );

                y -= 10;

                y = escribirLinea(
                        contenido,
                        fuenteNegrita,
                        12,
                        x,
                        y,
                        "2. Distribucion de lavado"
                );

                y = escribirDatoPDF(
                        contenido,
                        fuenteNormal,
                        x,
                        y,
                        "Lavado simple",
                        simples + " garrafones"
                );

                y = escribirDatoPDF(
                        contenido,
                        fuenteNormal,
                        x,
                        y,
                        "Lavado profundo",
                        profundos + " garrafones"
                );

                y -= 10;

                y = escribirLinea(
                        contenido,
                        fuenteNegrita,
                        12,
                        x,
                        y,
                        "3. Configuracion del escenario"
                );

                y = escribirDatoPDF(
                        contenido,
                        fuenteNormal,
                        x,
                        y,
                        "Garrafones por camion",
                        String.valueOf(
                                parametros
                                        .getGarrafonesPorCamion()
                        )
                );

                y = escribirDatoPDF(
                        contenido,
                        fuenteNormal,
                        x,
                        y,
                        "Capacidad de llenadora",
                        String.valueOf(
                                parametros
                                        .getCapacidadLlenadora()
                        )
                );

                y = escribirDatoPDF(
                        contenido,
                        fuenteNormal,
                        x,
                        y,
                        "Tiempo lavado simple",
                        String.format(
                                "%.2f s",
                                parametros
                                        .getTiempoLavadoSimple()
                        )
                );

                y = escribirDatoPDF(
                        contenido,
                        fuenteNormal,
                        x,
                        y,
                        "Tiempo lavado profundo",
                        String.format(
                                "%.2f s",
                                parametros
                                        .getTiempoLavadoProfundo()
                        )
                );

                y = escribirDatoPDF(
                        contenido,
                        fuenteNormal,
                        x,
                        y,
                        "Tiempo de llenado",
                        String.format(
                                "%.2f s",
                                parametros
                                        .getTiempoProcesoLlenado()
                        )
                );

                y = escribirDatoPDF(
                        contenido,
                        fuenteNormal,
                        x,
                        y,
                        "Tiempo tapado y sellado",
                        String.format(
                                "%.2f s",
                                parametros
                                        .getTiempoTapadoSellado()
                        )
                );

                y -= 10;

                y = escribirLinea(
                        contenido,
                        fuenteNegrita,
                        12,
                        x,
                        y,
                        "4. Costos"
                );

                y = escribirDatoPDF(
                        contenido,
                        fuenteNormal,
                        x,
                        y,
                        "Costo total por hora",
                        formatoMoneda(costoHora)
                );

                y = escribirDatoPDF(
                        contenido,
                        fuenteNormal,
                        x,
                        y,
                        "Costo de personal de la corrida",
                        formatoMoneda(costoPersonal)
                );

                y = escribirDatoPDF(
                        contenido,
                        fuenteNormal,
                        x,
                        y,
                        "Costo por garrafon",
                        formatoMoneda(costoGarrafon)
                );

                y -= 10;

                y = escribirLinea(
                        contenido,
                        fuenteNegrita,
                        12,
                        x,
                        y,
                        "5. Proyeccion del escenario"
                );

                y = escribirDatoPDF(
                        contenido,
                        fuenteNormal,
                        x,
                        y,
                        "Numero de corridas",
                        String.valueOf(numeroCorridas)
                );

                y = escribirDatoPDF(
                        contenido,
                        fuenteNormal,
                        x,
                        y,
                        "Garrafones proyectados",
                        String.format("%,d", garrafonesProyectados)
                );

                y = escribirDatoPDF(
                        contenido,
                        fuenteNormal,
                        x,
                        y,
                        "Tiempo acumulado",
                        formatoTiempo(tiempoProyectadoSegundos)
                );

                y = escribirDatoPDF(
                        contenido,
                        fuenteNormal,
                        x,
                        y,
                        "Jornadas equivalentes de 8 horas",
                        String.format("%.2f", jornadasEquivalentes)
                );

                y = escribirDatoPDF(
                        contenido,
                        fuenteNormal,
                        x,
                        y,
                        "Costo de personal por hora",
                        formatoMoneda(costoHora)
                );

                y = escribirDatoPDF(
                        contenido,
                        fuenteNormal,
                        x,
                        y,
                        "Costo laboral proyectado",
                        formatoMoneda(costoLaboralProyectado)
                );

                y = escribirDatoPDF(
                        contenido,
                        fuenteNormal,
                        x,
                        y,
                        "Costo proyectado por garrafon",
                        formatoMoneda(costoGarrafonProyectado)
                );
            }

            documento.save(
                    archivo
            );
        }
    }


    // =========================================================
    // EXPORTAR EXCEL
    // =========================================================

    public static File exportarExcel(
            MotorSimulacion motor,
            Window ventanaPropietaria) throws IOException {

        validarMotor(motor);

        FileChooser selector =
                new FileChooser();

        selector.setTitle(
                "Guardar resultados Excel - Agua Cero"
        );

        selector.getExtensionFilters().add(
                new FileChooser.ExtensionFilter(
                        "Libro de Excel (*.xlsx)",
                        "*.xlsx"
                )
        );

        selector.setInitialFileName(
                "Resultados_AguaCero_"
                        + LocalDateTime.now()
                        .format(FECHA_ARCHIVO)
                        + ".xlsx"
        );

        File archivo =
                selector.showSaveDialog(
                        ventanaPropietaria
                );

        if (archivo == null) {
            return null;
        }

        archivo = asegurarExtension(
                archivo,
                ".xlsx"
        );

        crearExcel(
                motor,
                archivo
        );

        return archivo;
    }


    private static void crearExcel(
            MotorSimulacion motor,
            File archivo) throws IOException {

        ParametrosSimulacion parametros =
                motor.getParametros();

        double tiempoSegundos =
                motor.getTiempoActual();

        int terminados =
                motor.getCantidadTerminados();

        int total =
                motor.getTotalProcesados();

        int simples =
                motor.contarTipoLavado(
                        TipoLavado.SIMPLE
                );

        int profundos =
                motor.contarTipoLavado(
                        TipoLavado.PROFUNDO
                );

        double productividad =
                calcularProductividad(
                        terminados,
                        tiempoSegundos
                );

        double costoHora =
                parametros.getCostoTotalPorHora();

        double costoPersonal =
                costoHora
                        * (tiempoSegundos / 3600.0);

        double costoGarrafon =
                terminados > 0
                        ? costoPersonal / terminados
                        : 0.0;

        // =====================================================
        // PROYECCIÓN DEL ESCENARIO
        // =====================================================

        int numeroCorridas =
                Math.max(
                        1,
                        parametros.getNumeroCorridas()
                );

        long garrafonesProyectados =
                (long) terminados
                        * numeroCorridas;

        double tiempoProyectadoSegundos =
                tiempoSegundos
                        * numeroCorridas;

        double horasProyectadas =
                tiempoProyectadoSegundos
                        / 3600.0;

        double jornadasEquivalentes =
                horasProyectadas
                        / 8.0;

        double costoLaboralProyectado =
                costoHora
                        * horasProyectadas;

        double costoGarrafonProyectado =
                garrafonesProyectados > 0
                        ? costoLaboralProyectado / garrafonesProyectados
                        : 0.0;

        try (Workbook libro =
                     new XSSFWorkbook()) {

            Sheet hoja =
                    libro.createSheet(
                            "Resultados"
                    );

            Font fuenteTitulo =
                    libro.createFont();

            fuenteTitulo.setBold(
                    true
            );

            fuenteTitulo.setFontHeightInPoints(
                    (short) 16
            );

            CellStyle estiloTitulo =
                    libro.createCellStyle();

            estiloTitulo.setFont(
                    fuenteTitulo
            );


            Font fuenteSeccion =
                    libro.createFont();

            fuenteSeccion.setBold(
                    true
            );

            CellStyle estiloSeccion =
                    libro.createCellStyle();

            estiloSeccion.setFont(
                    fuenteSeccion
            );


            int fila = 0;

            Row titulo =
                    hoja.createRow(
                            fila++
                    );

            Cell celdaTitulo =
                    titulo.createCell(
                            0
                    );

            celdaTitulo.setCellValue(
                    "AGUA CERO - RESULTADOS Y ESTADISTICAS"
            );

            celdaTitulo.setCellStyle(
                    estiloTitulo
            );


            agregarFila(
                    hoja,
                    fila++,
                    "Fecha del reporte",
                    LocalDateTime.now()
                            .format(FECHA_REPORTE)
            );

            fila++;


            agregarSeccion(
                    hoja,
                    fila++,
                    "RESULTADOS GENERALES",
                    estiloSeccion
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Garrafones procesados",
                    total
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Garrafones terminados",
                    terminados
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Tiempo total (segundos)",
                    tiempoSegundos
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Tiempo total",
                    formatoTiempo(tiempoSegundos)
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Productividad (garrafones/h)",
                    productividad
            );

            fila++;


            agregarSeccion(
                    hoja,
                    fila++,
                    "DISTRIBUCION DE LAVADO",
                    estiloSeccion
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Lavado simple",
                    simples
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Lavado profundo",
                    profundos
            );

            fila++;


            agregarSeccion(
                    hoja,
                    fila++,
                    "CONFIGURACION DEL ESCENARIO",
                    estiloSeccion
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Garrafones por camion",
                    parametros
                            .getGarrafonesPorCamion()
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Capacidad de llenadora",
                    parametros
                            .getCapacidadLlenadora()
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Tiempo lavado simple (s)",
                    parametros
                            .getTiempoLavadoSimple()
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Tiempo lavado profundo (s)",
                    parametros
                            .getTiempoLavadoProfundo()
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Tiempo carga llenadora (s)",
                    parametros
                            .getTiempoCargaLlenadora()
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Tiempo llenado (s)",
                    parametros
                            .getTiempoProcesoLlenado()
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Tiempo descarga llenadora (s)",
                    parametros
                            .getTiempoDescargaLlenadora()
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Tiempo tapado y sellado (s)",
                    parametros
                            .getTiempoTapadoSellado()
            );

            fila++;


            agregarSeccion(
                    hoja,
                    fila++,
                    "COSTOS",
                    estiloSeccion
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Costo total por hora",
                    costoHora
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Costo de personal de la corrida",
                    costoPersonal
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Costo por garrafon",
                    costoGarrafon
            );

            fila++;


            agregarSeccion(
                    hoja,
                    fila++,
                    "PROYECCION DEL ESCENARIO",
                    estiloSeccion
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Numero de corridas",
                    numeroCorridas
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Garrafones proyectados",
                    (double) garrafonesProyectados
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Tiempo acumulado (segundos)",
                    tiempoProyectadoSegundos
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Tiempo acumulado",
                    formatoTiempo(tiempoProyectadoSegundos)
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Horas laborales acumuladas",
                    horasProyectadas
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Jornadas equivalentes de 8 horas",
                    jornadasEquivalentes
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Costo de personal por hora",
                    costoHora
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Costo laboral proyectado",
                    costoLaboralProyectado
            );

            agregarFila(
                    hoja,
                    fila++,
                    "Costo proyectado por garrafon",
                    costoGarrafonProyectado
            );


            hoja.setColumnWidth(
                    0,
                    38 * 256
            );

            hoja.setColumnWidth(
                    1,
                    28 * 256
            );


            try (FileOutputStream salida =
                         new FileOutputStream(
                                 archivo
                         )) {

                libro.write(
                        salida
                );
            }
        }
    }


    // =========================================================
    // MÉTODOS AUXILIARES PDF
    // =========================================================

    private static float escribirLinea(
            PDPageContentStream contenido,
            PDType1Font fuente,
            float tamano,
            float x,
            float y,
            String texto) throws IOException {

        contenido.beginText();

        contenido.setFont(
                fuente,
                tamano
        );

        contenido.newLineAtOffset(
                x,
                y
        );

        contenido.showText(
                limpiarTextoPDF(texto)
        );

        contenido.endText();

        return y - 18;
    }


    private static float escribirDatoPDF(
            PDPageContentStream contenido,
            PDType1Font fuente,
            float x,
            float y,
            String etiqueta,
            String valor) throws IOException {

        return escribirLinea(
                contenido,
                fuente,
                10,
                x,
                y,
                etiqueta + ": " + valor
        );
    }


    // =========================================================
    // MÉTODOS AUXILIARES EXCEL
    // =========================================================

    private static void agregarSeccion(
            Sheet hoja,
            int numeroFila,
            String texto,
            CellStyle estilo) {

        Row fila =
                hoja.createRow(
                        numeroFila
                );

        Cell celda =
                fila.createCell(
                        0
                );

        celda.setCellValue(
                texto
        );

        celda.setCellStyle(
                estilo
        );
    }


    private static void agregarFila(
            Sheet hoja,
            int numeroFila,
            String etiqueta,
            String valor) {

        Row fila =
                hoja.createRow(
                        numeroFila
                );

        fila.createCell(
                0
        ).setCellValue(
                etiqueta
        );

        fila.createCell(
                1
        ).setCellValue(
                valor
        );
    }


    private static void agregarFila(
            Sheet hoja,
            int numeroFila,
            String etiqueta,
            double valor) {

        Row fila =
                hoja.createRow(
                        numeroFila
                );

        fila.createCell(
                0
        ).setCellValue(
                etiqueta
        );

        fila.createCell(
                1
        ).setCellValue(
                valor
        );
    }


    // =========================================================
    // UTILIDADES GENERALES
    // =========================================================

    private static void validarMotor(
            MotorSimulacion motor) {

        if (motor == null) {

            throw new IllegalArgumentException(
                    "No existe una simulacion para exportar."
            );
        }
    }


    private static double calcularProductividad(
            int terminados,
            double tiempoSegundos) {

        if (tiempoSegundos <= 0) {
            return 0.0;
        }

        return terminados
                / (tiempoSegundos / 3600.0);
    }


    private static String formatoTiempo(
            double segundosTotales) {

        long total =
                Math.max(
                        0,
                        Math.round(segundosTotales)
                );

        long horas =
                total / 3600;

        long minutos =
                (total % 3600) / 60;

        long segundos =
                total % 60;

        return String.format(
                "%02d:%02d:%02d",
                horas,
                minutos,
                segundos
        );
    }


    private static String formatoMoneda(
            double cantidad) {

        return String.format(
                "$%,.2f",
                cantidad
        );
    }


    private static File asegurarExtension(
            File archivo,
            String extension) {

        if (archivo
                .getName()
                .toLowerCase()
                .endsWith(extension)) {

            return archivo;
        }

        return new File(
                archivo.getParentFile(),
                archivo.getName()
                        + extension
        );
    }


    private static String limpiarTextoPDF(
            String texto) {

        if (texto == null) {
            return "";
        }

        /*
         * Las fuentes estándar de PDFBox trabajan mejor con
         * caracteres simples. Se sustituyen algunos caracteres
         * especiales para evitar errores al exportar.
         */
        return texto
                .replace("á", "a")
                .replace("é", "e")
                .replace("í", "i")
                .replace("ó", "o")
                .replace("ú", "u")
                .replace("Á", "A")
                .replace("É", "E")
                .replace("Í", "I")
                .replace("Ó", "O")
                .replace("Ú", "U")
                .replace("ñ", "n")
                .replace("Ñ", "N")
                .replace("•", "-");
    }
}

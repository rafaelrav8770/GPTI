package com.nietosystems.aguacero.simulacion;

/**
 * Define los tipos de lavado que puede requerir
 * un garrafón dentro de la planta Agua Cero.
 */
public enum TipoLavado {

    /**
     * Para garrafones semisucios.
     * Tiempo base: 30 segundos por unidad.
     */
    SIMPLE,

    /**
     * Para garrafones muy sucios.
     * Tiempo base: 60 segundos por unidad.
     */
    PROFUNDO
}
package com.nietosystems.aguacero.simulacion;

/**
 * Representa a un empleado dentro de la simulación
 * de la planta Agua Cero.
 */
public class Empleado {

    // =========================================================
    // DATOS GENERALES
    // =========================================================

    /**
     * Identificador del empleado.
     * Ejemplo: 1, 2, 3, 4, 5.
     */
    private final int id;

    /**
     * Nombre que se mostrará en la interfaz.
     */
    private String nombre;

    /**
     * Actividad que está realizando actualmente.
     */
    private String actividadActual;

    /**
     * Indica si el empleado se encuentra ocupado.
     */
    private boolean ocupado;


    // =========================================================
    // CONTROL DE TIEMPOS
    // =========================================================

    /**
     * Tiempo simulado acumulado durante el cual
     * el empleado estuvo ocupado.
     */
    private double tiempoTotalOcupado;

    /**
     * Momento en el que comenzó la actividad actual.
     */
    private double tiempoInicioActividad;

    /**
     * Número de actividades realizadas.
     */
    private int actividadesRealizadas;


    // =========================================================
    // CONSTRUCTOR
    // =========================================================

    public Empleado(int id, String nombre) {

        this.id = id;
        this.nombre = nombre;

        this.actividadActual = "En espera";
        this.ocupado = false;

        this.tiempoTotalOcupado = 0;
        this.tiempoInicioActividad = 0;

        this.actividadesRealizadas = 0;
    }


    // =========================================================
    // INICIAR ACTIVIDAD
    // =========================================================

    /**
     * Marca al empleado como ocupado e indica
     * qué actividad comenzó a realizar.
     *
     * @param actividad actividad que realizará.
     * @param tiempoActual segundo actual de la simulación.
     */
    public void iniciarActividad(
            String actividad,
            double tiempoActual) {

        // Evitamos iniciar otra actividad
        // si el empleado ya está ocupado.
        if (ocupado) {
            return;
        }

        this.actividadActual = actividad;
        this.ocupado = true;

        this.tiempoInicioActividad = tiempoActual;
    }


    // =========================================================
    // FINALIZAR ACTIVIDAD
    // =========================================================

    /**
     * Finaliza la actividad actual y acumula
     * el tiempo durante el cual estuvo ocupado.
     *
     * @param tiempoActual segundo actual de la simulación.
     */
    public void finalizarActividad(double tiempoActual) {

        if (!ocupado) {
            return;
        }

        double duracion =
                tiempoActual - tiempoInicioActividad;

        if (duracion > 0) {
            tiempoTotalOcupado += duracion;
        }

        actividadesRealizadas++;

        actividadActual = "En espera";
        ocupado = false;

        tiempoInicioActividad = 0;
    }


    // =========================================================
    // UTILIZACIÓN
    // =========================================================

    /**
     * Calcula el porcentaje de utilización del empleado
     * durante el tiempo transcurrido de la simulación.
     *
     * Ejemplo:
     *
     * Tiempo transcurrido = 100 segundos
     * Tiempo ocupado = 75 segundos
     *
     * Utilización = 75 %
     */
    public double calcularUtilizacion(
            double tiempoActual) {

        if (tiempoActual <= 0) {
            return 0;
        }

        double ocupadoAcumulado =
                tiempoTotalOcupado;

        /*
         * Si actualmente sigue trabajando,
         * también contamos el tiempo de la
         * actividad que todavía no ha terminado.
         */
        if (ocupado) {

            ocupadoAcumulado +=
                    tiempoActual - tiempoInicioActividad;
        }

        double utilizacion =
                (ocupadoAcumulado / tiempoActual) * 100.0;

        /*
         * Protección para evitar porcentajes
         * mayores a 100 por algún error numérico.
         */
        return Math.min(utilizacion, 100.0);
    }


    // =========================================================
    // REINICIAR
    // =========================================================

    /**
     * Regresa al empleado a su estado inicial.
     * Se utilizará cuando se reinicie una corrida.
     */
    public void reiniciar() {

        actividadActual = "En espera";
        ocupado = false;

        tiempoTotalOcupado = 0;
        tiempoInicioActividad = 0;

        actividadesRealizadas = 0;
    }


    // =========================================================
    // GETTERS
    // =========================================================

    public int getId() {
        return id;
    }


    public String getNombre() {
        return nombre;
    }


    public String getActividadActual() {
        return actividadActual;
    }


    public boolean isOcupado() {
        return ocupado;
    }


    public double getTiempoTotalOcupado() {
        return tiempoTotalOcupado;
    }


    public double getTiempoInicioActividad() {
        return tiempoInicioActividad;
    }


    public int getActividadesRealizadas() {
        return actividadesRealizadas;
    }


    // =========================================================
    // SETTERS
    // =========================================================

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


    // =========================================================
    // MÉTODOS AUXILIARES
    // =========================================================

    /**
     * Indica si el empleado está disponible
     * para recibir una nueva tarea.
     */
    public boolean estaDisponible() {
        return !ocupado;
    }


    @Override
    public String toString() {

        return "Empleado{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", actividadActual='" + actividadActual + '\'' +
                ", ocupado=" + ocupado +
                '}';
    }
}
package com.nietosystems.aguacero.controller;

import com.nietosystems.aguacero.AcercaApplication;
import com.nietosystems.aguacero.ConfiguracionApplication;
import com.nietosystems.aguacero.ResultadosApplication;
import com.nietosystems.aguacero.SimulacionApplication;

import javafx.fxml.FXML;


/**
 * Controlador principal del sistema Agua Cero.
 *
 * Administra la navegación desde el panel principal hacia
 * los diferentes módulos de la aplicación.
 */
public class MainController {


    // =========================================================
    // SIMULACIÓN
    // =========================================================

    @FXML
    protected void onSimulacionClick() {

        SimulacionApplication.mostrar();
    }


    // =========================================================
    // CONFIGURACIÓN
    // =========================================================

    @FXML
    protected void onConfiguracionClick() {

        ConfiguracionApplication.mostrar();
    }


    // =========================================================
    // RESULTADOS Y ESTADÍSTICAS
    // =========================================================

    @FXML
    protected void onResultadosClick() {

        ResultadosApplication.mostrar();
    }


    // =========================================================
    // ACERCA DEL PROYECTO
    // =========================================================

    @FXML
    protected void onAcercaDeClick() {

        /*
         * Abre la ventana informativa del proyecto Agua Cero.
         */

        AcercaApplication.mostrar();
    }


    // =========================================================
    // SALIR DEL SISTEMA
    // =========================================================

    @FXML
    protected void onSalirClick() {

        System.exit(0);
    }
}
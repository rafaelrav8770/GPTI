module com.nietosystems.aguacero {

    // =========================================================
    // JAVAFX
    // =========================================================

    requires javafx.controls;
    requires javafx.fxml;


    // =========================================================
    // LIBRERÍAS DE INTERFAZ
    // =========================================================

    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;


    // =========================================================
    // EXPORTACIÓN PDF
    // Apache PDFBox
    // =========================================================

    requires org.apache.pdfbox;


    // =========================================================
    // EXPORTACIÓN EXCEL
    // Apache POI
    // =========================================================

    requires org.apache.poi.poi;
    requires org.apache.poi.ooxml;


    // =========================================================
    // JAVAFX FXML
    // =========================================================

    opens com.nietosystems.aguacero to javafx.fxml;

    opens com.nietosystems.aguacero.controller to javafx.fxml;


    // =========================================================
    // PAQUETES EXPORTADOS
    // =========================================================

    exports com.nietosystems.aguacero;

    exports com.nietosystems.aguacero.controller;
}
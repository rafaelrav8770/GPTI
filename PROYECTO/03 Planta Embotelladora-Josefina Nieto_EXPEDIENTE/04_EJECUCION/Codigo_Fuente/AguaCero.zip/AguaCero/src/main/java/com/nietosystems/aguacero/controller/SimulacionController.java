package com.nietosystems.aguacero.controller;

import com.nietosystems.aguacero.simulacion.Empleado;
import com.nietosystems.aguacero.simulacion.MotorSimulacion;
import com.nietosystems.aguacero.simulacion.ParametrosSimulacion;
import com.nietosystems.aguacero.MainApplication;
import com.nietosystems.aguacero.ResultadosApplication;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.List;

public class SimulacionController {

    // =========================================================
    // MOTOR
    // =========================================================

    private MotorSimulacion motor;
    private Timeline timeline;

    /*Conserva la última simulación terminada para que el módulo Resultados
    y estadísticas pueda consultarla*/
    private static MotorSimulacion ultimaSimulacionTerminada;

    // =========================================================
    // ÚLTIMA SIMULACIÓN TERMINADA
    // =========================================================

    public static MotorSimulacion getUltimaSimulacionTerminada() {

        return ultimaSimulacionTerminada;
    }

    // =========================================================
    // INDICADORES GENERALES
    // =========================================================

    @FXML
    private Label lblEstado;

    @FXML
    private Label lblProcesados;

    @FXML
    private Label lblEnSistema;

    @FXML
    private Label lblTerminados;

    @FXML
    private Button btnResultados;


    // =========================================================
    // DESCARGA
    // =========================================================

    @FXML
    private Label lblDescarga;

    @FXML
    private Label lblPorcentajeDescarga;

    @FXML
    private Label lblEstadoDescarga;


    // =========================================================
    // RECEPCIÓN Y CLASIFICACIÓN
    // =========================================================

    @FXML
    private Label lblColaRecepcion;

    @FXML
    private Label lblClasificacion;


    // =========================================================
    // LAVADOS
    // =========================================================

    @FXML
    private Label lblColaLavadoSimple;

    @FXML
    private Label lblEstadoLavadoSimple;

    @FXML
    private Label lblColaLavadoProfundo;

    @FXML
    private Label lblEstadoLavadoProfundo;


    // =========================================================
    // LLENADO
    // =========================================================

    @FXML
    private Label lblColaLlenado;

    @FXML
    private Label lblCargaLlenado;

    @FXML
    private Label lblEstadoLlenado;


    // =========================================================
    // TAPADO Y SELLADO
    // =========================================================

    @FXML
    private Label lblEstadoSellado;


    // =========================================================
    // TRASLADO A PRODUCTO TERMINADO
    // =========================================================

    @FXML
    private Label lblColaTraslado;

    @FXML
    private Label lblGrupoTraslado;

    @FXML
    private Label lblEstadoTraslado;


    // =========================================================
    // PRODUCTO TERMINADO
    // =========================================================

    @FXML
    private Label lblProductoTerminado;


    // =========================================================
    // EMPLEADOS
    // =========================================================

    @FXML
    private Label lblEmpleado1Actividad;

    @FXML
    private Label lblEmpleado1Estado;

    @FXML
    private Label lblEmpleado1Utilizacion;

    @FXML
    private Label lblEmpleado2Actividad;

    @FXML
    private Label lblEmpleado2Estado;

    @FXML
    private Label lblEmpleado2Utilizacion;

    @FXML
    private Label lblEmpleado3Actividad;

    @FXML
    private Label lblEmpleado3Estado;

    @FXML
    private Label lblEmpleado3Utilizacion;

    @FXML
    private Label lblEmpleado4Actividad;

    @FXML
    private Label lblEmpleado4Estado;

    @FXML
    private Label lblEmpleado4Utilizacion;

    @FXML
    private Label lblEmpleado5Actividad;

    @FXML
    private Label lblEmpleado5Estado;

    @FXML
    private Label lblEmpleado5Utilizacion;


    // =========================================================
    // REPRESENTACIÓN VISUAL DEL FLUJO
    // =========================================================

    @FXML
    private ImageView imgGarrafonDescarga;

    @FXML
    private ImageView imgGarrafonRecepcion;

    @FXML
    private ImageView imgGarrafonClasificacion;

    @FXML
    private ImageView imgGarrafonLavadoSimple;

    @FXML
    private ImageView imgGarrafonLavadoProfundo;

    @FXML
    private ImageView imgGarrafonColaLlenado;

    @FXML
    private ImageView imgGarrafonLlenado;

    @FXML
    private ImageView imgGarrafonSellado;

    @FXML
    private ImageView imgGarrafonTraslado;

    @FXML
    private ImageView imgGarrafonTerminado;


    // =========================================================
    // INICIALIZACIÓN
    // =========================================================

    @FXML
    public void initialize() {

        // Recuperar la configuración guardada por el usuario
        ParametrosSimulacion parametrosGuardados =
                ConfiguracionController.getParametrosGuardados();

        // Si existe una configuración guardada,
        // el motor trabajará con ella.
        if (parametrosGuardados != null) {

            motor = new MotorSimulacion(parametrosGuardados);

            System.out.println(
                    "Simulación iniciada con la configuración guardada."
            );

        } else {

            // Si el usuario entra directamente a Simulación
            // sin configurar previamente, usamos los valores
            // predeterminados.
            motor = new MotorSimulacion();

            System.out.println(
                    "Simulación iniciada con parámetros predeterminados."
            );
        }

        timeline = new Timeline(
                new KeyFrame(
                        Duration.millis(100),
                        event -> avanzarSimulacion()
                )
        );

        timeline.setCycleCount(
                Timeline.INDEFINITE
        );

        // Los resultados de esta pantalla solo se habilitan
        // cuando la corrida actual termina completamente.
        if (btnResultados != null) {
            btnResultados.setDisable(true);
        }

        actualizarInterfaz();
    }


    // =========================================================
    // AVANZAR SIMULACIÓN
    // =========================================================

    private void avanzarSimulacion() {

        if (motor == null
                || !motor.isEjecutando()
                || motor.isPausada()) {
            return;
        }

        // Procesa un segundo completo del modelo de simulación.
        // Este método avanza el reloj Y ejecuta descarga, clasificación,
        // lavados, llenado, tapado/sellado y traslado final.
        motor.procesarSegundo();

        // Refresca descarga, colas, procesos, empleados e imágenes.
        actualizarInterfaz();

        if (motor.getCantidadTerminados()
                >= motor.getParametros().getGarrafonesPorCamion()) {

            motor.finalizar();

            // Conserva esta corrida para Resultados y estadísticas.
            ultimaSimulacionTerminada = motor;

            if (timeline != null) {
                timeline.stop();
            }

            lblEstado.setText(
                    "SIMULACIÓN FINALIZADA"
            );

            if (btnResultados != null) {
                btnResultados.setDisable(false);
            }

            actualizarInterfaz();

            System.out.println(
                    "Resultados de la simulación guardados correctamente."
            );
        }
    }


    // =========================================================
    // INICIAR
    // =========================================================

    @FXML
    protected void onIniciarClick() {

        if (!motor.isEjecutando()) {

            motor.iniciar();

            lblEstado.setText(
                    "SIMULACIÓN EN EJECUCIÓN"
            );

            actualizarInterfaz();

            timeline.play();

            return;
        }

        if (motor.isPausada()) {

            motor.continuar();

            lblEstado.setText(
                    "SIMULACIÓN EN EJECUCIÓN"
            );

            timeline.play();
        }
    }


    // =========================================================
    // PAUSAR
    // =========================================================

    @FXML
    protected void onPausarClick() {

        if (!motor.isEjecutando()) {
            return;
        }

        motor.pausar();

        timeline.pause();

        lblEstado.setText(
                "SIMULACIÓN EN PAUSA"
        );

        actualizarInterfaz();
    }


    // =========================================================
    // REINICIAR
    // =========================================================

    @FXML
    protected void onReiniciarClick() {

        timeline.stop();

        motor.reiniciar();

        if (btnResultados != null) {
            btnResultados.setDisable(true);
        }

        lblEstado.setText(
                "LISTO"
        );

        actualizarInterfaz();
    }


    // =========================================================
    // RESULTADOS Y ESTADÍSTICAS
    // =========================================================

    @FXML
    protected void onResultadosClick() {

        if (ultimaSimulacionTerminada == null) {
            return;
        }

        if (timeline != null) {
            timeline.stop();
        }

        ResultadosApplication.mostrar();
    }


    // =========================================================
    // VOLVER
    // =========================================================

    @FXML
    protected void onVolverClick() {

        /*
         * Detenemos la animación de la simulación
         * antes de abandonar esta pantalla.
         */
        if (timeline != null) {
            timeline.stop();
        }

        /*
         * Finalizamos correctamente el motor.
         */
        if (motor != null) {
            motor.finalizar();
        }

        /*
         * Regresamos a la ventana principal.
         *
         * Ya no utilizamos stage.close(), porque toda
         * la aplicación trabaja sobre una sola ventana.
         */
        MainApplication.mostrarPrincipal();
    }


    // =========================================================
    // ACTUALIZAR INTERFAZ
    // =========================================================

    private void actualizarInterfaz() {

        if (motor == null) {
            return;
        }


        // =====================================================
        // INDICADORES
        // =====================================================

        lblProcesados.setText(
                String.valueOf(
                        motor.getTotalProcesados()
                )
        );

        lblEnSistema.setText(
                String.valueOf(
                        motor.getCantidadEnSistema()
                )
        );

        lblTerminados.setText(
                String.valueOf(
                        motor.getCantidadTerminados()
                )
        );


        // =====================================================
        // DESCARGA
        // =====================================================

        int totalGarrafones =
                motor.getParametros()
                        .getGarrafonesPorCamion();

        int descargados =
                motor.getGarrafonesDescargados();

        lblDescarga.setText(
                "Garrafones descargados: "
                        + descargados
                        + " / "
                        + totalGarrafones
        );

        lblPorcentajeDescarga.setText(
                String.format(
                        "Progreso: %.0f %%",
                        motor.getPorcentajeDescarga()
                )
        );


        if (!motor.isEjecutando()
                && descargados == 0) {

            lblEstadoDescarga.setText(
                    "Estado: Esperando"
            );

            lblEstadoDescarga.setStyle(
                    "-fx-text-fill: #64748B;"
                            + "-fx-font-weight: bold;"
            );

        } else if (motor.isDescargaInicialActiva()) {

            lblEstadoDescarga.setText(
                    "Estado: DESCARGANDO"
            );

            lblEstadoDescarga.setStyle(
                    "-fx-text-fill: #B45309;"
                            + "-fx-font-weight: bold;"
            );

        } else if (descargados
                == totalGarrafones
                && totalGarrafones > 0) {

            lblEstadoDescarga.setText(
                    "Estado: COMPLETADA"
            );

            lblEstadoDescarga.setStyle(
                    "-fx-text-fill: #166534;"
                            + "-fx-font-weight: bold;"
            );
        }


        // =====================================================
        // RECEPCIÓN
        // =====================================================

        lblColaRecepcion.setText(
                "En recepción: "
                        + motor.getCantidadEnRecepcion()
        );


        // =====================================================
        // CLASIFICACIÓN
        // =====================================================

        if (motor.isDescargaInicialActiva()) {

            lblClasificacion.setText(
                    "ESPERANDO DESCARGA"
            );

        } else if (!motor.isClasificacionRealizada()) {

            lblClasificacion.setText(
                    "CLASIFICANDO"
            );

        } else {

            lblClasificacion.setText(
                    "COMPLETADA"
            );
        }


        // =====================================================
        // LAVADO SIMPLE
        // =====================================================

        lblColaLavadoSimple.setText(
                "Cola: "
                        + motor
                        .getCantidadColaLavadoSimple()
        );

        if (motor.isLavadoSimpleOcupado()) {

            lblEstadoLavadoSimple.setText(
                    "Estado: PROCESANDO"
            );

            lblEstadoLavadoSimple.setStyle(
                    "-fx-text-fill: #B45309;"
                            + "-fx-font-weight: bold;"
            );

        } else {

            lblEstadoLavadoSimple.setText(
                    "Estado: DISPONIBLE"
            );

            lblEstadoLavadoSimple.setStyle(
                    "-fx-text-fill: #166534;"
                            + "-fx-font-weight: bold;"
            );
        }


        // =====================================================
        // LAVADO PROFUNDO
        // =====================================================

        lblColaLavadoProfundo.setText(
                "Cola: "
                        + motor
                        .getCantidadColaLavadoProfundo()
        );

        if (motor.isLavadoProfundoOcupado()) {

            lblEstadoLavadoProfundo.setText(
                    "Estado: PROCESANDO"
            );

            lblEstadoLavadoProfundo.setStyle(
                    "-fx-text-fill: #B45309;"
                            + "-fx-font-weight: bold;"
            );

        } else {

            lblEstadoLavadoProfundo.setText(
                    "Estado: DISPONIBLE"
            );

            lblEstadoLavadoProfundo.setStyle(
                    "-fx-text-fill: #166534;"
                            + "-fx-font-weight: bold;"
            );
        }


        // =====================================================
        // COLA DE LLENADO
        // =====================================================

        lblColaLlenado.setText(
                "Garrafones en cola: "
                        + motor
                        .getCantidadColaLlenado()
        );


        // =====================================================
        // LLENADORA
        // =====================================================

        lblCargaLlenado.setText(
                "Carga actual: "
                        + motor
                        .getCantidadEnLlenadora()
                        + " / "
                        + motor
                        .getParametros()
                        .getCapacidadLlenadora()
        );


        String estadoLlenadora =
                motor.getEstadoLlenadora();


        switch (estadoLlenadora) {

            case "CARGANDO":

                lblEstadoLlenado.setText(
                        "Estado: CARGANDO"
                );

                break;


            case "LLENANDO":

                lblEstadoLlenado.setText(
                        "Estado: LLENANDO"
                );

                break;


            case "ESPERANDO_DESCARGA":

                lblEstadoLlenado.setText(
                        "Estado: ESPERANDO A E3"
                );

                break;


            case "DESCARGANDO":

                lblEstadoLlenado.setText(
                        "Estado: DESCARGANDO"
                );

                break;


            default:

                lblEstadoLlenado.setText(
                        "Estado: DISPONIBLE"
                );

                break;
        }


        if (estadoLlenadora.equals("LIBRE")) {

            lblEstadoLlenado.setStyle(
                    "-fx-text-fill: #166534;"
                            + "-fx-font-weight: bold;"
            );

        } else if (estadoLlenadora
                .equals("ESPERANDO_DESCARGA")) {

            lblEstadoLlenado.setStyle(
                    "-fx-text-fill: #B91C1C;"
                            + "-fx-font-weight: bold;"
            );

        } else {

            lblEstadoLlenado.setStyle(
                    "-fx-text-fill: #B45309;"
                            + "-fx-font-weight: bold;"
            );
        }


        // =====================================================
        // TAPADO Y SELLADO
        // =====================================================

        if (motor.isTapadoSelladoOcupado()) {

            lblEstadoSellado.setText(
                    "Estado: PROCESANDO"
            );

            lblEstadoSellado.setStyle(
                    "-fx-text-fill: #B45309;"
                            + "-fx-font-weight: bold;"
            );

        } else {

            lblEstadoSellado.setText(
                    "Estado: DISPONIBLE"
            );

            lblEstadoSellado.setStyle(
                    "-fx-text-fill: #166534;"
                            + "-fx-font-weight: bold;"
            );
        }


        // =====================================================
        // TRASLADO A PRODUCTO TERMINADO
        // =====================================================

        lblColaTraslado.setText(
                "En espera: "
                        + motor.getCantidadColaTraslado()
        );


        lblGrupoTraslado.setText(
                "Grupo actual: "
                        + motor.getCantidadEnTraslado()
                        + " / "
                        + motor.getCapacidadTraslado()
        );


        if (motor.isTrasladoActivo()) {

            lblEstadoTraslado.setText(
                    "Estado: TRASLADANDO"
            );

            lblEstadoTraslado.setStyle(
                    "-fx-text-fill: #B45309;"
                            + "-fx-font-weight: bold;"
            );

        } else {

            if (motor.getCantidadColaTraslado() > 0
                    && motor.getCantidadColaTraslado()
                    < motor.getCapacidadTraslado()) {

                lblEstadoTraslado.setText(
                        "Estado: ESPERANDO GRUPO DE 4"
                );

                lblEstadoTraslado.setStyle(
                        "-fx-text-fill: #B45309;"
                                + "-fx-font-weight: bold;"
                );

            } else {

                lblEstadoTraslado.setText(
                        "Estado: DISPONIBLE"
                );

                lblEstadoTraslado.setStyle(
                        "-fx-text-fill: #166534;"
                                + "-fx-font-weight: bold;"
                );
            }
        }


        // =====================================================
        // PRODUCTO TERMINADO
        // =====================================================

        lblProductoTerminado.setText(
                "Total: "
                        + motor.getCantidadTerminados()
                        + " garrafones"
        );


        // =====================================================
        // EMPLEADOS
        // =====================================================

        actualizarEmpleados();


        // =====================================================
        // REPRESENTACIÓN VISUAL
        // =====================================================

        actualizarGarrafonesVisuales();
    }


    // =========================================================
    // ACTUALIZAR REPRESENTACIÓN VISUAL DEL FLUJO
    // =========================================================

    private void actualizarGarrafonesVisuales() {

        /*
         * Cada imagen representa actividad en una etapa.
         * No representa físicamente a uno de los 40 garrafones.
         *
         * Primero ocultamos todos y después mostramos aquellos
         * correspondientes a las etapas activas.
         */
        ocultarGarrafonesVisuales();

        if (motor == null) {
            return;
        }

        int totalGarrafones =
                motor.getParametros()
                        .getGarrafonesPorCamion();

        int descargados =
                motor.getGarrafonesDescargados();


        // =====================================================
        // DESCARGA
        // =====================================================

        /*
         * Antes de iniciar dejamos visible el garrafón en descarga.
         * También permanece visible mientras se realiza la descarga.
         */
        if ((!motor.isEjecutando() && descargados == 0)
                || motor.isDescargaInicialActiva()) {

            mostrarGarrafon(
                    imgGarrafonDescarga
            );
        }


        // =====================================================
        // RECEPCIÓN
        // =====================================================

        if (motor.getCantidadEnRecepcion() > 0) {

            mostrarGarrafon(
                    imgGarrafonRecepcion
            );
        }


        // =====================================================
        // CLASIFICACIÓN
        // =====================================================

        if (!motor.isDescargaInicialActiva()
                && descargados == totalGarrafones
                && !motor.isClasificacionRealizada()) {

            mostrarGarrafon(
                    imgGarrafonClasificacion
            );
        }


        // =====================================================
        // LAVADO SIMPLE
        // =====================================================

        /*
         * Se muestra si existe un garrafón siendo procesado
         * o si existen garrafones esperando esta ruta.
         */
        if (motor.isLavadoSimpleOcupado()
                || motor.getCantidadColaLavadoSimple() > 0) {

            mostrarGarrafon(
                    imgGarrafonLavadoSimple
            );
        }


        // =====================================================
        // LAVADO PROFUNDO
        // =====================================================

        if (motor.isLavadoProfundoOcupado()
                || motor.getCantidadColaLavadoProfundo() > 0) {

            mostrarGarrafon(
                    imgGarrafonLavadoProfundo
            );
        }


        // =====================================================
        // COLA DE LLENADO
        // =====================================================

        if (motor.getCantidadColaLlenado() > 0) {

            mostrarGarrafon(
                    imgGarrafonColaLlenado
            );
        }


        // =====================================================
        // MÁQUINA DE LLENADO
        // =====================================================

        /*
         * Cualquier estado distinto de LIBRE significa
         * que existe actividad en la llenadora.
         */
        if (!"LIBRE".equals(
                motor.getEstadoLlenadora()
        )
                || motor.getCantidadEnLlenadora() > 0) {

            mostrarGarrafon(
                    imgGarrafonLlenado
            );
        }


        // =====================================================
        // TAPADO Y SELLADO
        // =====================================================

        if (motor.isTapadoSelladoOcupado()) {

            mostrarGarrafon(
                    imgGarrafonSellado
            );
        }


        // =====================================================
        // TRASLADO
        // =====================================================

        /*
         * También lo mostramos si existen garrafones esperando
         * completar el grupo de cuatro.
         */
        if (motor.isTrasladoActivo()
                || motor.getCantidadColaTraslado() > 0
                || motor.getCantidadEnTraslado() > 0) {

            mostrarGarrafon(
                    imgGarrafonTraslado
            );
        }


        // =====================================================
        // PRODUCTO TERMINADO
        // =====================================================

        /*
         * Cuando llega al menos un garrafón,
         * este indicador permanece visible.
         */
        if (motor.getCantidadTerminados() > 0) {

            mostrarGarrafon(
                    imgGarrafonTerminado
            );
        }
    }


    // =========================================================
    // OCULTAR TODOS LOS GARRAFONES VISUALES
    // =========================================================

    private void ocultarGarrafonesVisuales() {

        ocultarGarrafon(
                imgGarrafonDescarga
        );

        ocultarGarrafon(
                imgGarrafonRecepcion
        );

        ocultarGarrafon(
                imgGarrafonClasificacion
        );

        ocultarGarrafon(
                imgGarrafonLavadoSimple
        );

        ocultarGarrafon(
                imgGarrafonLavadoProfundo
        );

        ocultarGarrafon(
                imgGarrafonColaLlenado
        );

        ocultarGarrafon(
                imgGarrafonLlenado
        );

        ocultarGarrafon(
                imgGarrafonSellado
        );

        ocultarGarrafon(
                imgGarrafonTraslado
        );

        ocultarGarrafon(
                imgGarrafonTerminado
        );
    }


    // =========================================================
    // MOSTRAR UN GARRAFÓN
    // =========================================================

    private void mostrarGarrafon(
            ImageView imagen) {

        if (imagen != null) {

            imagen.setOpacity(
                    1.0
            );
        }
    }


    // =========================================================
    // OCULTAR UN GARRAFÓN
    // =========================================================

    private void ocultarGarrafon(
            ImageView imagen) {

        if (imagen != null) {

            imagen.setOpacity(
                    0.0
            );
        }
    }


    // =========================================================
    // ACTUALIZAR EMPLEADOS
    // =========================================================

    private void actualizarEmpleados() {

        List<Empleado> empleados =
                motor.getEmpleados();

        for (Empleado empleado : empleados) {

            switch (empleado.getId()) {

                case 1:

                    actualizarEmpleado(
                            empleado,
                            lblEmpleado1Actividad,
                            lblEmpleado1Estado,
                            lblEmpleado1Utilizacion
                    );

                    break;


                case 2:

                    actualizarEmpleado(
                            empleado,
                            lblEmpleado2Actividad,
                            lblEmpleado2Estado,
                            lblEmpleado2Utilizacion
                    );

                    break;


                case 3:

                    actualizarEmpleado(
                            empleado,
                            lblEmpleado3Actividad,
                            lblEmpleado3Estado,
                            lblEmpleado3Utilizacion
                    );

                    break;


                case 4:

                    actualizarEmpleado(
                            empleado,
                            lblEmpleado4Actividad,
                            lblEmpleado4Estado,
                            lblEmpleado4Utilizacion
                    );

                    break;


                case 5:

                    actualizarEmpleado(
                            empleado,
                            lblEmpleado5Actividad,
                            lblEmpleado5Estado,
                            lblEmpleado5Utilizacion
                    );

                    break;


                default:
                    break;
            }
        }
    }


    // =========================================================
    // ACTUALIZAR UN EMPLEADO
    // =========================================================

    private void actualizarEmpleado(
            Empleado empleado,
            Label lblActividad,
            Label lblEstadoEmpleado,
            Label lblUtilizacion) {


        // =====================================================
        // ACTIVIDAD
        // =====================================================

        lblActividad.setText(
                "Actividad: "
                        + empleado
                        .getActividadActual()
        );


        // =====================================================
        // ESTADO
        // =====================================================

        if (empleado.isOcupado()) {

            lblEstadoEmpleado.setText(
                    "● OCUPADO"
            );

            lblEstadoEmpleado.setStyle(
                    "-fx-text-fill: #B45309;"
                            + "-fx-font-weight: bold;"
            );

        } else {

            lblEstadoEmpleado.setText(
                    "● DISPONIBLE"
            );

            lblEstadoEmpleado.setStyle(
                    "-fx-text-fill: #166534;"
                            + "-fx-font-weight: bold;"
            );
        }


        // =====================================================
        // UTILIZACIÓN
        // =====================================================

        double utilizacion =
                empleado.calcularUtilizacion(
                        motor.getTiempoActual()
                );

        lblUtilizacion.setText(
                String.format(
                        "Utilización: %.1f %%",
                        utilizacion
                )
        );
    }
}

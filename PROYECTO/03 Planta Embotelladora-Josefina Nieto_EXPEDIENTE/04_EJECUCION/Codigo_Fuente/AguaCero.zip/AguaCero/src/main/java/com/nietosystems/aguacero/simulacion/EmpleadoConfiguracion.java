package com.nietosystems.aguacero.simulacion;

import java.util.ArrayList;
import java.util.List;


public class EmpleadoConfiguracion {

    // =========================================================
    // DATOS GENERALES
    // =========================================================

    private final int id;

    private String nombre;

    private boolean activo;

    private double costoPorHora;


    // =========================================================
    // ACTIVIDADES PERMITIDAS
    // =========================================================

    private final List<String> actividadesPermitidas;


    // =========================================================
    // CONSTRUCTOR
    // =========================================================

    public EmpleadoConfiguracion(
            int id,
            String nombre) {

        this.id = id;
        this.nombre = nombre;

        this.activo = true;
        this.costoPorHora = 0.0;

        this.actividadesPermitidas =
                new ArrayList<>();
    }


    // =========================================================
    // CONSTRUCTOR COMPLETO
    // =========================================================

    public EmpleadoConfiguracion(
            int id,
            String nombre,
            boolean activo,
            double costoPorHora) {

        this.id = id;
        this.nombre = nombre;
        this.activo = activo;
        this.costoPorHora = costoPorHora;

        this.actividadesPermitidas =
                new ArrayList<>();
    }


    // =========================================================
    // AGREGAR ACTIVIDAD
    // =========================================================

    public void agregarActividad(String actividad) {

        if (actividad == null) {
            return;
        }

        String actividadLimpia =
                actividad.trim();

        if (actividadLimpia.isEmpty()) {
            return;
        }

        if (!actividadesPermitidas.contains(
                actividadLimpia)) {

            actividadesPermitidas.add(
                    actividadLimpia
            );
        }
    }


    // =========================================================
    // ELIMINAR ACTIVIDAD
    // =========================================================

    public void eliminarActividad(String actividad) {

        actividadesPermitidas.remove(
                actividad
        );
    }


    // =========================================================
    // LIMPIAR ACTIVIDADES
    // =========================================================

    public void limpiarActividades() {

        actividadesPermitidas.clear();
    }


    // =========================================================
    // PUEDE REALIZAR ACTIVIDAD
    // =========================================================

    /**
     * Permite preguntar al motor si este empleado
     * puede realizar determinada actividad.
     */
    public boolean puedeRealizar(
            String actividad) {

        if (!activo) {
            return false;
        }

        if (actividad == null) {
            return false;
        }

        return actividadesPermitidas.contains(
                actividad
        );
    }


    // =========================================================
    // GETTERS
    // =========================================================

    public int getId() {
        return id;
    }


    public String getNombre() {
        return nombre;
    }


    public boolean isActivo() {
        return activo;
    }


    public double getCostoPorHora() {
        return costoPorHora;
    }


    /**
     * Regresa una copia para evitar que otra clase
     * modifique accidentalmente la lista interna.
     */
    public List<String> getActividadesPermitidas() {

        return new ArrayList<>(
                actividadesPermitidas
        );
    }


    // =========================================================
    // SETTERS
    // =========================================================

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


    public void setActivo(boolean activo) {
        this.activo = activo;
    }


    public void setCostoPorHora(
            double costoPorHora) {

        if (costoPorHora < 0) {
            return;
        }

        this.costoPorHora =
                costoPorHora;
    }


    // =========================================================
    // TO STRING
    // =========================================================

    @Override
    public String toString() {

        return "EmpleadoConfiguracion{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", activo=" + activo +
                ", costoPorHora=" + costoPorHora +
                ", actividadesPermitidas=" +
                actividadesPermitidas +
                '}';
    }
}
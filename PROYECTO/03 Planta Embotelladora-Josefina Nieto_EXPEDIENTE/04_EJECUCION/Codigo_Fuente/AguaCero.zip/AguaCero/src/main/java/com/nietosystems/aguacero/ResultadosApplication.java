package com.nietosystems.aguacero;

import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.stage.Screen;
import javafx.stage.Stage;

import java.io.IOException;

public class ResultadosApplication {

    public static void mostrar() {

        try {

            // =====================================================
            // CARGAR FXML
            // =====================================================

            FXMLLoader loader = new FXMLLoader(
                    ResultadosApplication.class.getResource(
                            "resultados-view.fxml"
                    )
            );


            // =====================================================
            // OBTENER PANTALLA DISPONIBLE
            // =====================================================

            Rectangle2D pantallaDisponible =
                    Screen.getPrimary().getVisualBounds();


            // =====================================================
            // CREAR ESCENA
            // =====================================================

            Scene scene = new Scene(
                    loader.load(),
                    pantallaDisponible.getWidth(),
                    pantallaDisponible.getHeight()
            );


            // =====================================================
            // UTILIZAR EL MISMO STAGE PRINCIPAL
            // =====================================================

            Stage stage =
                    MainApplication.getStagePrincipal();

            stage.setTitle(
                    "Agua Cero | Resultados y estadísticas"
            );

            stage.setScene(scene);

            stage.setResizable(true);

            stage.setMinWidth(850);
            stage.setMinHeight(600);


            // =====================================================
            // AJUSTAR A LA PANTALLA
            // =====================================================

            stage.setX(
                    pantallaDisponible.getMinX()
            );

            stage.setY(
                    pantallaDisponible.getMinY()
            );

            stage.setWidth(
                    pantallaDisponible.getWidth()
            );

            stage.setHeight(
                    pantallaDisponible.getHeight()
            );


            // =====================================================
            // CERRAR = REGRESAR AL MENÚ PRINCIPAL
            // =====================================================

            stage.setOnCloseRequest(event -> {

                event.consume();

                MainApplication.mostrarPrincipal();
            });


        } catch (IOException e) {

            System.err.println(
                    "Error al abrir Resultados y estadísticas."
            );

            e.printStackTrace();
        }
    }
}
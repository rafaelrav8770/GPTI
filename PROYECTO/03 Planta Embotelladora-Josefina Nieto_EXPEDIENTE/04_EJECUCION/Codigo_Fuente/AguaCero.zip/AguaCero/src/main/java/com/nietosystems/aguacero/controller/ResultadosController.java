package com.nietosystems.aguacero.controller;

import com.nietosystems.aguacero.MainApplication;
import com.nietosystems.aguacero.ExportadorResultados;
import com.nietosystems.aguacero.simulacion.Empleado;
import com.nietosystems.aguacero.simulacion.MotorSimulacion;
import com.nietosystems.aguacero.simulacion.ParametrosSimulacion;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.HBox;

import java.util.List;

public class ResultadosController {


    // =========================================================
    // INDICADORES GENERALES
    // =========================================================

    @FXML
    private Label lblTerminados;

    @FXML
    private Label lblTiempoTotal;

    @FXML
    private Label lblProductividad;

    @FXML
    private Label lblCostoTotal;


    // =========================================================
    // RENDIMIENTO DEL PROCESO
    // =========================================================

    @FXML
    private Label lblProcesados;

    @FXML
    private Label lblLavadoSimple;

    @FXML
    private Label lblLavadoProfundo;

    @FXML
    private Label lblTerminadosDetalle;


    // =========================================================
    // EMPLEADOS
    // =========================================================

    @FXML
    private ProgressBar barraEmpleado1;

    @FXML
    private ProgressBar barraEmpleado2;

    @FXML
    private ProgressBar barraEmpleado3;

    @FXML
    private ProgressBar barraEmpleado4;

    @FXML
    private ProgressBar barraEmpleado5;


    @FXML
    private Label lblEmpleado1;

    @FXML
    private Label lblEmpleado2;

    @FXML
    private Label lblEmpleado3;

    @FXML
    private Label lblEmpleado4;

    @FXML
    private Label lblEmpleado5;


    @FXML
    private HBox filaEmpleado5;


    // =========================================================
    // COSTOS
    // =========================================================

    @FXML
    private Label lblCostoPersonal;

    @FXML
    private Label lblCostoGarrafon;

    @FXML
    private Label lblCostoTotalDetalle;


    // =========================================================
    // PROYECCIÓN DE CORRIDAS
    // =========================================================

    @FXML
    private Label lblNumeroCorridas;

    @FXML
    private Label lblGarrafonesProyectados;

    @FXML
    private Label lblTiempoProyectado;

    @FXML
    private Label lblJornadasEquivalentes;

    @FXML
    private Label lblCostoHoraProyectado;

    @FXML
    private Label lblCostoLaboralProyectado;

    @FXML
    private Label lblCostoGarrafonProyectado;


    // =========================================================
    // ANÁLISIS
    // =========================================================

    @FXML
    private Label lblCuelloBotella;

    @FXML
    private Label lblRecomendacion;


    // =========================================================
    // INICIALIZACIÓN
    // =========================================================

    @FXML
    public void initialize() {

        cargarResultados();
    }


    // =========================================================
    // CARGAR RESULTADOS
    // =========================================================

    private void cargarResultados() {

        MotorSimulacion motor =
                SimulacionController
                        .getUltimaSimulacionTerminada();


        /*
         * Si todavía no existe una simulación terminada,
         * mantenemos la pantalla en estado vacío.
         */
        if (motor == null) {

            mostrarSinResultados();

            return;
        }


        // =====================================================
        // RESULTADOS GENERALES
        // =====================================================

        int terminados =
                motor.getCantidadTerminados();

        int procesados =
                motor.getTotalProcesados();

        double tiempoSegundos =
                motor.getTiempoActual();


        lblTerminados.setText(
                String.valueOf(terminados)
        );

        lblTerminadosDetalle.setText(
                String.valueOf(terminados)
        );

        lblProcesados.setText(
                String.valueOf(procesados)
        );


        // =====================================================
        // TIEMPO TOTAL
        // =====================================================

        lblTiempoTotal.setText(
                convertirTiempo(tiempoSegundos)
        );


        // =====================================================
        // PRODUCTIVIDAD
        // =====================================================

        double productividad = 0;

        if (tiempoSegundos > 0) {

            double horas =
                    tiempoSegundos / 3600.0;

            productividad =
                    terminados / horas;
        }

        lblProductividad.setText(
                String.format(
                        "%.2f",
                        productividad
                )
        );


        // =====================================================
        // DISTRIBUCIÓN DE LAVADOS
        // =====================================================

        /*
         * Estos valores corresponden a la distribución
         * configurada para el lote de la simulación.
         */
        int totalGarrafones =
                motor.getParametros()
                        .getGarrafonesPorCamion();

        int profundos =
                (int) Math.round(
                        totalGarrafones * 0.30
                );

        int simples =
                totalGarrafones - profundos;


        lblLavadoSimple.setText(
                String.valueOf(simples)
        );

        lblLavadoProfundo.setText(
                String.valueOf(profundos)
        );


        // =====================================================
        // UTILIZACIÓN DE EMPLEADOS
        // =====================================================

        cargarUtilizacionEmpleados(
                motor
        );


        // =====================================================
        // COSTOS
        // =====================================================

        cargarCostos(
                motor,
                tiempoSegundos,
                terminados
        );


        // =====================================================
        // PROYECCIÓN DE CORRIDAS
        // =====================================================

        cargarProyeccion(
                motor,
                tiempoSegundos,
                terminados
        );


        // =====================================================
        // ANÁLISIS
        // =====================================================

        lblCuelloBotella.setText(
                "🔍 Cuello de botella: revise la utilización de los recursos."
        );

        lblRecomendacion.setText(
                "💡 Compare la utilización, el tiempo total y el costo "
                        + "del escenario para apoyar la toma de decisiones."
        );
    }


    // =========================================================
    // COSTOS
    // =========================================================

    private void cargarCostos(
            MotorSimulacion motor,
            double tiempoSegundos,
            int terminados) {

        ParametrosSimulacion parametros =
                motor.getParametros();

        /*
         * El costo por hora proviene de la configuración
         * guardada para ESTA corrida. Si el usuario cambia
         * los costos en Configuración, este cálculo se adapta.
         *
         * E5 solamente se suma cuando está activo.
         */
        double costoTotalPorHora =
                parametros.getCostoTotalPorHora();

        double horasCorrida =
                tiempoSegundos / 3600.0;

        double costoPersonal =
                costoTotalPorHora * horasCorrida;

        double costoPorGarrafon = 0.0;

        if (terminados > 0) {
            costoPorGarrafon =
                    costoPersonal / terminados;
        }

        lblCostoTotal.setText(
                formatoMoneda(costoPersonal)
        );

        lblCostoPersonal.setText(
                formatoMoneda(costoPersonal)
        );

        lblCostoGarrafon.setText(
                formatoMoneda(costoPorGarrafon)
        );

        lblCostoTotalDetalle.setText(
                formatoMoneda(costoPersonal)
        );
    }


    // =========================================================
    // PROYECCIÓN DE CORRIDAS
    // =========================================================

    private void cargarProyeccion(
            MotorSimulacion motor,
            double tiempoSegundos,
            int terminados) {

        ParametrosSimulacion parametros =
                motor.getParametros();

        /*
         * La simulación visual se ejecuta UNA sola vez.
         *
         * El número de corridas se utiliza únicamente como
         * factor de proyección de producción, tiempo y costo.
         */
        int numeroCorridas =
                Math.max(
                        1,
                        parametros.getNumeroCorridas()
                );

        long garrafonesProyectados =
                (long) terminados
                        * numeroCorridas;

        double tiempoProyectadoSegundos =
                tiempoSegundos
                        * numeroCorridas;

        double horasProyectadas =
                tiempoProyectadoSegundos
                        / 3600.0;

        /*
         * La jornada laboral de Agua Cero es de 8 horas.
         * Este dato indica cuántas jornadas equivalentes
         * representa el tiempo acumulado proyectado.
         */
        double jornadasEquivalentes =
                horasProyectadas
                        / 8.0;

        /*
         * El costo laboral depende de las horas acumuladas,
         * no de multiplicar un salario diario directamente
         * por el número de corridas.
         */
        double costoPorHora =
                parametros.getCostoTotalPorHora();

        double costoLaboralProyectado =
                costoPorHora
                        * horasProyectadas;

        double costoGarrafonProyectado =
                0.0;

        if (garrafonesProyectados > 0) {

            costoGarrafonProyectado =
                    costoLaboralProyectado
                            / garrafonesProyectados;
        }


        lblNumeroCorridas.setText(
                String.valueOf(
                        numeroCorridas
                )
        );

        lblGarrafonesProyectados.setText(
                String.format(
                        "%,d",
                        garrafonesProyectados
                )
        );

        lblTiempoProyectado.setText(
                convertirTiempoProyectado(
                        tiempoProyectadoSegundos
                )
        );

        lblJornadasEquivalentes.setText(
                String.format(
                        "%.2f jornadas",
                        jornadasEquivalentes
                )
        );

        lblCostoHoraProyectado.setText(
                formatoMoneda(
                        costoPorHora
                )
        );

        lblCostoLaboralProyectado.setText(
                formatoMoneda(
                        costoLaboralProyectado
                )
        );

        lblCostoGarrafonProyectado.setText(
                formatoMoneda(
                        costoGarrafonProyectado
                )
        );
    }


    private String convertirTiempoProyectado(
            double segundosTotales) {

        long segundos =
                Math.max(
                        0,
                        Math.round(
                                segundosTotales
                        )
                );

        long horas =
                segundos / 3600;

        long minutos =
                (segundos % 3600) / 60;

        long segundosRestantes =
                segundos % 60;

        /*
         * A diferencia del tiempo de una corrida,
         * aquí las horas pueden superar 24 porque
         * se trata de tiempo acumulado.
         */
        return String.format(
                "%02d:%02d:%02d",
                horas,
                minutos,
                segundosRestantes
        );
    }


    private String formatoMoneda(double cantidad) {

        return String.format(
                "$%,.2f",
                cantidad
        );
    }


    // =========================================================
    // UTILIZACIÓN DE EMPLEADOS
    // =========================================================

    private void cargarUtilizacionEmpleados(
            MotorSimulacion motor) {

        List<Empleado> empleados =
                motor.getEmpleados();


        /*
         * Primero dejamos todos los indicadores en cero.
         */
        establecerUtilizacion(
                barraEmpleado1,
                lblEmpleado1,
                0
        );

        establecerUtilizacion(
                barraEmpleado2,
                lblEmpleado2,
                0
        );

        establecerUtilizacion(
                barraEmpleado3,
                lblEmpleado3,
                0
        );

        establecerUtilizacion(
                barraEmpleado4,
                lblEmpleado4,
                0
        );

        establecerUtilizacion(
                barraEmpleado5,
                lblEmpleado5,
                0
        );


        boolean empleado5Activo = false;


        for (Empleado empleado : empleados) {

            double utilizacion =
                    empleado.calcularUtilizacion(
                            motor.getTiempoActual()
                    );


            switch (empleado.getId()) {

                case 1:

                    establecerUtilizacion(
                            barraEmpleado1,
                            lblEmpleado1,
                            utilizacion
                    );

                    break;


                case 2:

                    establecerUtilizacion(
                            barraEmpleado2,
                            lblEmpleado2,
                            utilizacion
                    );

                    break;


                case 3:

                    establecerUtilizacion(
                            barraEmpleado3,
                            lblEmpleado3,
                            utilizacion
                    );

                    break;


                case 4:

                    establecerUtilizacion(
                            barraEmpleado4,
                            lblEmpleado4,
                            utilizacion
                    );

                    break;


                case 5:

                    empleado5Activo = true;

                    establecerUtilizacion(
                            barraEmpleado5,
                            lblEmpleado5,
                            utilizacion
                    );

                    break;


                default:
                    break;
            }
        }


        /*
         * E5 solamente aparece si estuvo activo
         * en el escenario ejecutado.
         */
        filaEmpleado5.setVisible(
                empleado5Activo
        );

        filaEmpleado5.setManaged(
                empleado5Activo
        );
    }


    // =========================================================
    // ESTABLECER UTILIZACIÓN
    // =========================================================

    private void establecerUtilizacion(
            ProgressBar barra,
            Label etiqueta,
            double utilizacion) {

        /*
         * calcularUtilizacion devuelve porcentaje:
         * por ejemplo 75.0.
         *
         * ProgressBar necesita un valor entre 0 y 1.
         */
        double progreso =
                utilizacion / 100.0;

        progreso =
                Math.max(
                        0,
                        Math.min(
                                progreso,
                                1
                        )
                );

        barra.setProgress(
                progreso
        );

        etiqueta.setText(
                String.format(
                        "%.1f %%",
                        utilizacion
                )
        );
    }


    // =========================================================
    // CONVERTIR SEGUNDOS A HH:MM:SS
    // =========================================================

    private String convertirTiempo(
            double segundosTotales) {

        int segundos =
                (int) Math.round(
                        segundosTotales
                );

        int horas =
                segundos / 3600;

        int minutos =
                (segundos % 3600) / 60;

        int segundosRestantes =
                segundos % 60;


        return String.format(
                "%02d:%02d:%02d",
                horas,
                minutos,
                segundosRestantes
        );
    }


    // =========================================================
    // SIN RESULTADOS
    // =========================================================

    private void mostrarSinResultados() {

        lblTerminados.setText("—");

        lblTiempoTotal.setText("--:--:--");

        lblProductividad.setText("—");

        lblProcesados.setText("—");

        lblLavadoSimple.setText("—");

        lblLavadoProfundo.setText("—");

        lblTerminadosDetalle.setText("—");


        establecerUtilizacion(
                barraEmpleado1,
                lblEmpleado1,
                0
        );

        establecerUtilizacion(
                barraEmpleado2,
                lblEmpleado2,
                0
        );

        establecerUtilizacion(
                barraEmpleado3,
                lblEmpleado3,
                0
        );

        establecerUtilizacion(
                barraEmpleado4,
                lblEmpleado4,
                0
        );

        establecerUtilizacion(
                barraEmpleado5,
                lblEmpleado5,
                0
        );


        filaEmpleado5.setVisible(false);

        filaEmpleado5.setManaged(false);


        lblCostoTotal.setText("$0.00");

        lblCostoPersonal.setText("$0.00");

        lblCostoGarrafon.setText("$0.00");

        lblCostoTotalDetalle.setText("$0.00");


        // Proyección sin resultados
        lblNumeroCorridas.setText("—");

        lblGarrafonesProyectados.setText("—");

        lblTiempoProyectado.setText("--:--:--");

        lblJornadasEquivalentes.setText("—");

        lblCostoHoraProyectado.setText("$0.00");

        lblCostoLaboralProyectado.setText("$0.00");

        lblCostoGarrafonProyectado.setText("$0.00");


        lblCuelloBotella.setText(
                "🔍 No existen resultados disponibles."
        );

        lblRecomendacion.setText(
                "💡 Ejecute primero una simulación completa "
                        + "para generar resultados y estadísticas."
        );
    }


    // =========================================================
    // REGRESAR
    // =========================================================

    @FXML
    protected void onRegresarClick() {

        MainApplication.mostrarPrincipal();
    }


    // =========================================================
    // EXPORTAR PDF
    // =========================================================

    @FXML
    protected void onExportarPdfClick() {

        MotorSimulacion motor =
                SimulacionController
                        .getUltimaSimulacionTerminada();

        if (motor == null) {

            mostrarMensaje(
                    "📄 Exportar PDF",
                    "Primero debe ejecutar una simulación completa "
                            + "para generar el reporte."
            );

            return;
        }

        try {

            java.io.File archivo =
                    ExportadorResultados.exportarPDF(
                            motor,
                            lblTerminados
                                    .getScene()
                                    .getWindow()
                    );

            if (archivo != null) {

                mostrarMensaje(
                        "📄 PDF generado",
                        "El reporte se guardó correctamente en:\n\n"
                                + archivo.getAbsolutePath()
                );
            }

        } catch (Exception e) {

            e.printStackTrace();

            mostrarMensaje(
                    "Error al exportar PDF",
                    "No fue posible generar el archivo PDF.\n\n"
                            + "Detalle: "
                            + e.getMessage()
            );
        }
    }


    // =========================================================
    // EXPORTAR EXCEL
    // =========================================================

    @FXML
    protected void onExportarExcelClick() {

        MotorSimulacion motor =
                SimulacionController
                        .getUltimaSimulacionTerminada();

        if (motor == null) {

            mostrarMensaje(
                    "📊 Exportar Excel",
                    "Primero debe ejecutar una simulación completa "
                            + "para generar el archivo."
            );

            return;
        }

        try {

            java.io.File archivo =
                    ExportadorResultados.exportarExcel(
                            motor,
                            lblTerminados
                                    .getScene()
                                    .getWindow()
                    );

            if (archivo != null) {

                mostrarMensaje(
                        "📊 Excel generado",
                        "El archivo se guardó correctamente en:\n\n"
                                + archivo.getAbsolutePath()
                );
            }

        } catch (Exception e) {

            e.printStackTrace();

            mostrarMensaje(
                    "Error al exportar Excel",
                    "No fue posible generar el archivo Excel.\n\n"
                            + "Detalle: "
                            + e.getMessage()
            );
        }
    }


    // =========================================================
    // MENSAJE
    // =========================================================

    private void mostrarMensaje(
            String titulo,
            String mensaje) {

        Alert alerta =
                new Alert(
                        Alert.AlertType.INFORMATION
                );

        alerta.setTitle(
                titulo
        );

        alerta.setHeaderText(
                null
        );

        alerta.setContentText(
                mensaje
        );

        alerta.showAndWait();
    }
}
